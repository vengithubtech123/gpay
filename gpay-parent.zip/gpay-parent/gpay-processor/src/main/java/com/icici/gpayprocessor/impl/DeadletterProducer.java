package com.icici.gpayprocessor.impl;

import com.icici.gpaycommon.exception.ProcessorException;
import com.icici.gpaycommon.serializer.PaymentSerializer;
import com.icici.gpayprocessor.helper.PropertyHelper;
import org.apache.kafka.clients.producer.ProducerConfig;

import java.util.Properties;

/**
 * @author aditya_shekhar on 1/20/2024
 */
public class DeadletterProducer {

    private Properties props;
    {
        props = PropertyHelper.getInstance().getProperties();
    }
    private String bootstrapServers = props.getProperty("BOOTSTRAP_SERVERS");
    private String activeProfile = props.getProperty("spring.profiles.active");

    public DeadletterProducer() throws ProcessorException {

    }
    private Properties brokerProps() {
        Properties props = new Properties();
        props.put("bootstrap.servers", bootstrapServers);
        props.put("acks", "all");
        props.put("retries", 0);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, PaymentSerializer.class.getName());
        if(activeProfile.equals("uat")) {
            props.put("ssl.truststore.location", DeadletterProducer.class.getResource("/cp.server.truststore.jks").getPath()
                    .substring(1));
            props.put("ssl.truststore.password" ,"changeit");
            props.put("ssl.keystore.location", DeadletterProducer.class.getResource("/cp.server.keystore.jks").getPath()
                    .substring(1));
            props.put("ssl.keystore.password" ,"changeit");
            props.put("security.protocol" ,"SSL");
            props.put("ssl.client.auth" ,"required");
            props.put("ssl.enabled.protocols" ,"TLSv1.2,TLSv1.1,TLSv1");
        }
        return props;
    }


}
