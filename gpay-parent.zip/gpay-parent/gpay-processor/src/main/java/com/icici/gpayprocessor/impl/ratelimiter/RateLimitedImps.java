package com.icici.gpayprocessor.impl.ratelimiter;

import com.icici.gpaycommon.dto.Payment;
import com.icici.gpaycommon.dto.PaymentRetry;
import com.icici.gpaycommon.enums.PAYMENT_STATUS;
import com.icici.gpaycommon.exception.ProcessorException;
import com.icici.gpaycommon.helper.PropertyHelper;
import com.icici.gpaycommon.serdes.PaymentImpsSerdes;
import com.icici.gpaycommon.serdes.PaymentSerdes;
import com.icici.gpaycommon.topic.KafkaTopics;
import com.icici.gpayprocessor.impl.BaseProcessor;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.*;
import org.apache.kafka.streams.kstream.*;

import java.time.Duration;
import java.util.Date;
import java.util.Properties;

/**
 * @author aditya_shekhar on 3/16/2024
 */
public class RateLimitedImps extends BaseProcessor {
    private Properties props;
    {
        props = PropertyHelper.getInstance().getProperties();
    }
    private String pmtImpsRequest = "imps_request";
    private String pmtRequestTopic = KafkaTopics.GPAY_PMT_REQUEST_TOPIC;
    private String pmtRequestAltTopic = KafkaTopics.GPAY_PMT_REQUEST_ALT_TOPIC;
    private String appID = "GPAY_IMPS_RATE-LIMITER_APP";//props.getProperty("GPAY_IMPS_RATE-LIMITER_APP");
    private StreamsBuilder builder = null;

    public RateLimitedImps() throws ProcessorException {
        super();
    }

    @Override
    public Topology build(StreamsBuilder builder) {
        builder = new StreamsBuilder();
        TimeWindows hoppingWindow = TimeWindows.of(Duration.ofSeconds(20)).advanceBy(Duration.ofSeconds(3));
        KStream<String, Payment> impsReqStream = builder.stream(pmtImpsRequest, Consumed.with(Serdes.String(),
                        PaymentImpsSerdes.serde()));
        //impsPendingStream.peek((k,v) -> System.out.println(k + " :: " + v.getTransactionId()));
        KStream<String, Payment> impsReqLimiterStream = impsReqStream.groupByKey().windowedBy(hoppingWindow)
                .reduce((value1, value2) -> {
                    System.out.println(value1.getSettlementId());
                    return value1;
                })
                .toStream( (windowedKey,value) ->  windowedKey.key());

        KStream<String, Payment> impsReqAltStream = builder.stream(pmtImpsRequest, Consumed.with(Serdes.String(),
                PaymentImpsSerdes.serde())).map( (key, val) -> KeyValue.pair(val.getTransactionId(), val));
        //impsPendingStream.peek((k,v) -> System.out.println(k + " :: " + v.getTransactionId()));
        KStream<String, Payment> impsReqAltLimiterStream = impsReqAltStream
                .groupByKey(Grouped.with(Serdes.String(), PaymentSerdes.serde()))
                .windowedBy(hoppingWindow)
                .reduce((value1, value2) -> {
                    System.out.println(value1.getSettlementId());
                    return value1;
                })
                .toStream( (windowedKey,value) ->  windowedKey.key());

        impsReqLimiterStream.peek((k,v) -> System.out.println(k + " :: " + v.getTransactionId()));
        impsReqLimiterStream.filter((k,v) -> v!=null && v.getUuid()!=null)
                .to(pmtRequestTopic, Produced.with(Serdes.String(), PaymentSerdes.serde()));

        impsReqAltLimiterStream.peek((k,v) -> System.out.println(k + " :: " + v.getTransactionId()));
        impsReqAltLimiterStream.filter((k,v) -> v!=null && v.getUuid()!=null)
                .to(pmtRequestAltTopic, Produced.with(Serdes.String(), PaymentSerdes.serde()));

        Topology topology = builder.build();
        return topology;
    }

    @Override
    public void run() {
        Topology topology = build(builder);
        super.streamsConfiguration.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, PaymentImpsSerdes.serde().getClass().getName());
        super.streamsConfiguration.put(StreamsConfig.APPLICATION_ID_CONFIG, appID);
        KafkaStreams streams = new KafkaStreams(topology, super.streamsConfiguration);
        streams.start();
    }

    public static void main(String[] args) throws ProcessorException {
        System.out.println("RateLimitedImps starting.....");
        BaseProcessor bp = new RateLimitedImps();
        bp.run();
        System.out.println("RateLimitedImps running now.....");
    }
}
