package com.icici.gpayprocessor;

import com.icici.gpaycommon.exception.ProcessorException;
import com.icici.gpayprocessor.impl.*;

/**
 * @author aditya_shekhar on 2/9/2024
 */

public class ProcessorApp {

    public static void main(String[] args) throws ProcessorException {

        System.out.println("PipelineDeduplicationProcessor starting.....");
        BaseProcessor bp1 = new PipelineDuplicationProcessor();
        bp1.run();
        System.out.println("PipelineDeduplicationProcessor running now.....");

        System.out.println("DedupAltProcessor starting.....");
        BaseProcessor bp2 = new DedupAltProcessor();
        bp2.run();
        System.out.println("DedupAltProcessor running now.....");

        System.out.println("DedupProcessor starting.....");
        BaseProcessor bp3 = new DedupProcessor();
        bp3.run();
        System.out.println("DedupProcessor running now.....");

        System.out.println("TransactionTrackingProcessor starting.....");
        BaseProcessor bp4 = new TransactionTrackingProcessor();
        bp4.run();
        System.out.println("TransactionTrackingProcessor running now.....");

        /*System.out.println("PipelineDeduplicationProcessor starting.....");
        BaseProcessor bp1 = new PipelineDeduplicationProcessor();
        bp1.run();
        System.out.println("PipelineDeduplicationProcessor running now.....");

        System.out.println("ImpsPendingTaskProcessor starting.....");
        BaseProcessor bp2 = new ImpsPendingTaskProcessor();
        bp2.run();
        System.out.println("ImpsPendingTaskProcessor running now.....");

        System.out.println("UpiPendingTaskProcessor starting.....");
        BaseProcessor bp3 = new UpiPendingTaskProcessor();
        bp3.run();
        System.out.println("UpiPendingTaskProcessor running now.....");

        System.out.println("NeftPendingTaskProcessor starting.....");
        BaseProcessor bp4 = new NeftPendingTaskProcessor();
        bp4.run();
        System.out.println("NeftPendingTaskProcessor running now.....");

        System.out.println("RtgsPendingTaskProcessor starting.....");
        BaseProcessor bp5 = new RtgsPendingTaskProcessor();
        bp5.run();
        System.out.println("RtgsPendingTaskProcessor running now.....");

        System.out.println("ImpsStatusCheckProcessor starting.....");
        BaseProcessor bp6 = new ImpsStatusCheckProcessor();
        bp6.run();
        System.out.println("ImpsStatusCheckProcessor running now.....");

        System.out.println("NeftStatusCheckProcessor starting.....");
        BaseProcessor bp7 = new NeftStatusCheckProcessor();
        bp7.run();
        System.out.println("NeftStatusCheckProcessor running now.....");

        System.out.println("UpiStatusCheckProcessor starting.....");
        BaseProcessor bp8 = new UpiStatusCheckProcessor();
        bp8.run();
        System.out.println("UpiStatusCheckProcessor running now.....");

        System.out.println("RtgsStatusCheckProcessor starting.....");
        BaseProcessor bp9 = new RtgsStatusCheckProcessor();
        bp9.run();
        System.out.println("RtgsStatusCheckProcessor running now.....");*/
    }
}
