package com.icici.gpayprocessor.impl;

import com.icici.gpaycommon.dto.Payment;
import com.icici.gpaycommon.exception.ProcessorException;
import com.icici.gpaycommon.serdes.PaymentSerdes;
import com.icici.gpaycommon.topic.KafkaTopics;
import com.icici.gpayprocessor.helper.PropertyHelper;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.*;
import org.apache.kafka.streams.kstream.*;

import java.util.Properties;

/**
 * @author aditya_shekhar on 2/20/2024
 */
public class PipelineDuplicationProcessor extends BaseProcessor {

    private Properties props;
    {
        props = PropertyHelper.getInstance().getProperties();
    }
    private String pmtReqTopic = KafkaTopics.GPAY_PMT_REQUEST_TOPIC;
    private String pmtValidStatusTopic = KafkaTopics.GPAY_PMT_VALID_STATUS_TOPIC;
    private String pmtValidStatusLogTopic = KafkaTopics.GPAY_PMT_VALID_STATUS_LOG_TOPIC;
    private String pmtRetryTrackerTopic = KafkaTopics.GPAY_PMT_PENDING_TRACKER_TOPIC;
    private String pmtPendingParkedTopic = KafkaTopics.GPAY_PMT_PENDING_PARKED_TOPIC;
    private String pmtCompleteTopic = KafkaTopics.GPAY_PMT_COMPLETE_TOPIC;
    private String pmtBlockedTopic = KafkaTopics.GPAY_PMT_BLOCKED_TOPIC;

    private String pmtReqAltTopic = KafkaTopics.GPAY_PMT_REQUEST_ALT_TOPIC;
    private String pmtValidStatusAltTopic = KafkaTopics.GPAY_PMT_VALID_STATUS_ALT_TOPIC;
    private String pmtValidStatusAltLogTopic = KafkaTopics.GPAY_PMT_VALID_STATUS_LOG_ALT_TOPIC;
    private String pmtRetryTrackerAltTopic = KafkaTopics.GPAY_PMT_PENDING_TRACKER_ALT_TOPIC;
    private String pmtPendingParkedAltTopic = KafkaTopics.GPAY_PMT_PENDING_PARKED_ALT_TOPIC;
    private String pmtCompleteAltTopic = KafkaTopics.GPAY_PMT_COMPLETE_ALT_TOPIC;
    private String pmtBlockedAltTopic = KafkaTopics.GPAY_PMT_BLOCKED_ALT_TOPIC;
    private String appID = props.getProperty("GPAY_DUPLICATOR_APP_ID");
    private StreamsBuilder builder = null;

    public PipelineDuplicationProcessor() throws ProcessorException {
        super();
    }

    @Override
    public Topology build(StreamsBuilder builder) {
        builder = new StreamsBuilder();
        KStream<String, Payment> pmtRequest = builder.stream(pmtReqTopic, Consumed.with(Serdes.String(), PaymentSerdes.serde()));
        KStream<String, Payment> pmtRetryTracker = builder.stream(pmtRetryTrackerTopic, Consumed.with(Serdes.String(), PaymentSerdes.serde()));
        KStream<String, Payment> pmtPendingParked = builder.stream(pmtPendingParkedTopic, Consumed.with(Serdes.String(), PaymentSerdes.serde()));
        KStream<String, Payment> pmtValidStatus = builder.stream(pmtValidStatusTopic, Consumed.with(Serdes.String(), PaymentSerdes.serde()));
        KStream<String, Payment> pmtComplete = builder.stream(pmtCompleteTopic, Consumed.with(Serdes.String(), PaymentSerdes.serde()));
        KStream<String, Payment> pmtBlocked = builder.stream(pmtBlockedTopic, Consumed.with(Serdes.String(), PaymentSerdes.serde()));

        KStream<String, Payment> pmtRequestAlt = pmtRequest.map( (key, val) -> KeyValue.pair(val.getTransactionId(), val));
        pmtRequestAlt.to(pmtReqAltTopic, Produced.with(Serdes.String(), PaymentSerdes.serde()));

        KStream<String, Payment> pmtRetryTrackerAlt = pmtRetryTracker.map( (key, val) -> KeyValue.pair(val.getTransactionId(), val));
        pmtRetryTrackerAlt.to(pmtRetryTrackerAltTopic, Produced.with(Serdes.String(), PaymentSerdes.serde()));

        KStream<String, Payment> pmtPendingParkedAlt = pmtPendingParked.map( (key, val) -> KeyValue.pair(val.getTransactionId(), val));
        pmtPendingParkedAlt.to(pmtPendingParkedAltTopic, Produced.with(Serdes.String(), PaymentSerdes.serde()));

        KStream<String, Payment> pmtValidStatusAlt = pmtValidStatus.map( (key, val) -> KeyValue.pair(val.getTransactionId(), val));
        pmtValidStatusAlt.to(pmtValidStatusAltTopic, Produced.with(Serdes.String(), PaymentSerdes.serde()));

        KStream<String, Payment> pmtCompleteAlt = pmtComplete.map( (key, val) -> KeyValue.pair(val.getTransactionId(), val));
        pmtCompleteAlt.to(pmtCompleteAltTopic, Produced.with(Serdes.String(), PaymentSerdes.serde()));

        KStream<String, Payment> pmtBlockedAlt = pmtBlocked.map( (key, val) -> KeyValue.pair(val.getTransactionId(), val));
        pmtBlockedAlt.to(pmtBlockedAltTopic, Produced.with(Serdes.String(), PaymentSerdes.serde()));

        Topology topology = builder.build();
        return topology;
    }

    @Override
    public void run() {
        Topology topology = build(builder);
        super.streamsConfiguration.put(StreamsConfig.APPLICATION_ID_CONFIG, appID);
        KafkaStreams streams = new KafkaStreams(topology, super.streamsConfiguration);
        streams.start();
    }

    /*public static void main(String[] args) throws ProcessorException {
        System.out.println("PipelineDeduplicationProcessor starting.....");
        BaseProcessor bp = new PipelineDuplicationProcessor();
        bp.run();
        System.out.println("PipelineDeduplicationProcessor running now.....");
    }*/
}