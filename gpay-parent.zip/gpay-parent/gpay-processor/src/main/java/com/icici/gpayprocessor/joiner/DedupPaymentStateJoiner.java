package com.icici.gpayprocessor.joiner;

import com.icici.gpaycommon.dto.Payment;
import com.icici.gpaycommon.dto.PaymentReference;
import com.icici.gpaycommon.dto.PaymentRetry;
import com.icici.gpaycommon.enums.PAYMENT_STATUS;
import org.apache.kafka.streams.kstream.ValueJoiner;

import java.util.Date;

/**
 * @author aditya_shekhar on 1/20/2024
 */
public class DedupPaymentStateJoiner implements ValueJoiner<Payment, Payment, Payment> {

    @Override
    public Payment apply(Payment payment1, Payment payment2) {
        Payment validPayment = null;
        if(payment1!=null && payment2==null) {
            validPayment = payment1;
        } else if(payment1==null && payment2!=null) {
            validPayment = payment2;
        } else if(payment1!=null && payment2!=null) {
            PaymentRetry p1Retry = payment1.getPaymentRetry();
            PaymentRetry p2Retry = payment2.getPaymentRetry();
            Date p1RetryTime = p1Retry!=null ? p1Retry.getLastRetryDatetime() : payment1.getPaymentReqDateTime();
            Date p2RetryTime = p2Retry!=null ? p2Retry.getLastRetryDatetime() : payment2.getPaymentReqDateTime();
            if(p1RetryTime.after(p2RetryTime)) {
                validPayment = payment1;
            } else if(p2RetryTime.after(p1RetryTime)) {
                validPayment = payment2;
            } else {
                validPayment = payment2;
            }
        }
        if(payment1!=null) {
            System.out.println("State :: payment1:- " + payment1.getSettlementId() + ":" + payment1.getTransactionId() + ":" + payment1.getPaymentStatus());
        }
        if(payment2!=null) {
            System.out.println("State :: payment2:- " + payment2.getSettlementId() + ":" + payment2.getTransactionId() + ":" + payment2.getPaymentStatus());
        }
        if(validPayment!=null) {
            System.out.println("State :: validPayment:- " + validPayment.getSettlementId() + ":" + validPayment.getTransactionId() + ":" + validPayment.getPaymentStatus());
        }
        return validPayment;
    }
}