package com.icici.gpayprocessor.helper;

import com.icici.gpaycommon.exception.ProcessorException;

import java.io.IOException;
import java.util.Properties;

/**
 * @author aditya_shekhar on 1/20/2024
 */
public class PropertyHelper {

    private static PropertyHelper instance;
    private Properties properties;

    public static PropertyHelper getInstance() throws ProcessorException {
        if(instance==null) {
            synchronized(PropertyHelper.class) {
                if(instance==null) {
                    try {
                        instance = new PropertyHelper();
                    } catch (IOException e) {
                        throw new ProcessorException(e.getCause().getMessage());
                    }
                }
            }
        }
        return instance;
    }

    private PropertyHelper() throws IOException {
        this.properties = getProp();
    }

    public Properties getProperties() {
        return properties;
    }

    private Properties getProp() throws IOException {
        final Properties prop = new Properties();
        prop.load(PropertyHelper.class.getResourceAsStream("/application.properties"));
        String activeProfile = prop.getProperty("spring.profiles.active");
        prop.load(PropertyHelper.class.getResourceAsStream("/application-"+activeProfile+".properties"));
        return prop;
    }
}
