package com.icici.gpayprocessor.joiner;

import com.icici.gpaycommon.dto.Payment;
import com.icici.gpaycommon.enums.PAYMENT_STATUS;
import org.apache.kafka.streams.kstream.ValueJoiner;

/**
 * @author aditya_shekhar on 1/20/2024
 */
public class PendingPaymentJoiner implements ValueJoiner<Payment, Payment, Payment>{

    @Override
    public Payment apply(Payment payment1, Payment payment2) {
        Payment validPayment = null;
        if(payment1!=null && payment2==null && payment1.getPaymentStatus()!=null && payment1.getPaymentStatus()==PAYMENT_STATUS.PENDING) {
            validPayment = payment1;
        }
        //Start: Fix for S1 T3  not getting blocked
        else if(payment1!=null && payment2!=null && payment2.getPaymentStatus()!=null &&
                (payment1.getPaymentStatus()==PAYMENT_STATUS.PENDING &&
                        (payment2.getPaymentStatus()==PAYMENT_STATUS.FAILED || payment2.getPaymentStatus()==PAYMENT_STATUS.SUCCESS)) ) {
            validPayment = payment1;
        }
        //End: Fix for S1 T3  not getting blocked
        else if(payment1!=null && payment2!=null && (payment2.getPaymentStatus()==PAYMENT_STATUS.SUCCESS /*||
                payment2.getPaymentStatus()==PAYMENT_STATUS.FAILED*/)) {
            validPayment = payment2;
        }
        return validPayment;
    }

}
