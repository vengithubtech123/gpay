package com.icici.gpayprocessor.joiner;

import com.icici.gpaycommon.dto.Payment;
import com.icici.gpaycommon.dto.PaymentRetry;
import com.icici.gpaycommon.enums.PAYMENT_STATUS;
import org.apache.kafka.streams.kstream.ValueJoiner;

import java.util.Date;

/**
 * @author aditya_shekhar on 2/27/2024
 */
public class TransactionStatusJoiner implements ValueJoiner<Payment, Payment, Payment>{

    @Override
    public Payment apply(Payment payment1, Payment payment2) {
        Payment validPayment = null;
        if(payment1!=null && payment2==null) {
            validPayment = payment1;
        } else if(payment1==null && payment2!=null) {
            validPayment = payment2;
        }
        //Start: Fix for Transaction status coming as null
        /*else if(payment1!=null && payment2!=null
                && payment1.getPaymentStatus().equals(PAYMENT_STATUS.PENDING) && payment2.getPaymentStatus().equals(PAYMENT_STATUS.FAILED)
                && payment1.getSettlementId().equalsIgnoreCase(payment2.getSettlementId())
                && !payment1.getTransactionId().equalsIgnoreCase(payment2.getTransactionId())) {
            validPayment = payment1;
        }*/
        //End: Fix for Transaction status coming as null
        else if(payment1!=null && payment2!=null && payment1.getSettlementId().equalsIgnoreCase(payment2.getSettlementId())
                && payment1.getTransactionId().equalsIgnoreCase(payment2.getTransactionId())) {
            PaymentRetry p1Retry = payment1.getPaymentRetry();
            PaymentRetry p2Retry = payment2.getPaymentRetry();
            Date p1RetryTime = p1Retry!=null && p1Retry.getLastRetryDatetime()!=null ?
                    p1Retry.getLastRetryDatetime() : payment1.getPaymentReqDateTime();
            Date p2RetryTime = p2Retry!=null && p2Retry.getLastRetryDatetime()!=null ?
                    p2Retry.getLastRetryDatetime() : payment2.getPaymentReqDateTime();
            if(p1RetryTime.after(p2RetryTime)) {
                validPayment = payment1;
            } else if(p2RetryTime.after(p1RetryTime)) {
                validPayment = payment2;
            } else {
                validPayment = payment2;
            }
        } else {
            validPayment = payment1;
        }
        return validPayment;
    }

}
