package com.icici.gpayprocessor.joiner;

import com.icici.gpaycommon.dto.Payment;
import com.icici.gpaycommon.enums.PAYMENT_STATUS;
import org.apache.kafka.streams.kstream.ValueJoiner;

/**
 * @author aditya_shekhar on 2/27/2024
 */
public class TransactionStatusJoiner implements ValueJoiner<Payment, Payment, Payment>{

    @Override
    public Payment apply(Payment payment1, Payment payment2) {
        Payment validPayment = null;
        if(payment1!=null && payment2==null) {
            validPayment = payment1;
        } else if(payment1==null && payment2!=null) {
            validPayment = payment2;
        }
        //Start: Fix for Transaction status coming as null
        else if(payment1!=null && payment2!=null
                && payment1.getPaymentStatus().equals(PAYMENT_STATUS.PENDING) && payment2.getPaymentStatus().equals(PAYMENT_STATUS.FAILED)
                && payment1.getSettlementId().equalsIgnoreCase(payment2.getSettlementId())
                && !payment1.getTransactionId().equalsIgnoreCase(payment2.getTransactionId())) {
            validPayment = payment1;
        }
        //End: Fix for Transaction status coming as null
        else if(payment1!=null && payment2!=null) {
            if(payment1.getPaymentReqDateTime().after(payment2.getPaymentReqDateTime())) {
                validPayment = payment1;
            } else if(payment2.getPaymentReqDateTime().after(payment1.getPaymentReqDateTime())) {
                validPayment = payment2;
            } else {
                validPayment = payment2;
            }

        }
        return validPayment;
    }

}
