package com.icici.gpayprocessor.joiner;

import com.icici.gpaycommon.dto.Payment;
import com.icici.gpaycommon.dto.PaymentReference;
import com.icici.gpaycommon.enums.PAYMENT_STATUS;
import org.apache.kafka.streams.kstream.ValueJoiner;

/**
 * @author aditya_shekhar on 1/20/2024
 */
public class DedupAltPaymentJoiner implements ValueJoiner<Payment, Payment, Payment> {

    @Override
    public Payment apply(Payment payment1, Payment payment2) {
        Payment validPayment = null;
        if(payment1!=null && payment1.getPaymentStatus()!=null && payment1.getPaymentStatus()!=PAYMENT_STATUS.WIP) {
            validPayment = payment1;
        } else if(payment1!=null && payment2==null) {
            validPayment = payment1;
            validPayment.setPaymentStatus(PAYMENT_STATUS.WIP);
        } else if((payment1.getSettlementId().equals(payment2.getSettlementId()) ||
                payment1.getTransactionId().equals(payment2.getTransactionId())) && payment2!=null && (payment2.getPaymentStatus()==
                PAYMENT_STATUS.SUCCESS || payment2.getPaymentStatus()==PAYMENT_STATUS.PENDING ||
                payment2.getPaymentStatus()==PAYMENT_STATUS.FAILED ||
                payment2.getPaymentStatus()==PAYMENT_STATUS.PARKED_PENDING ||
                payment2.getPaymentStatus()==PAYMENT_STATUS.DUPLICATE_REJECTED ||
                payment2.getPaymentStatus()==PAYMENT_STATUS.DUPLICATE_SETTLEMENT_REJECTED ||
                payment2.getPaymentStatus()==PAYMENT_STATUS.DUPLICATE_TRANSACTION_REJECTED)) {
            validPayment = payment1;
            PaymentReference refPayment = null;
            if(payment2.getPaymentStatus()== PAYMENT_STATUS.SUCCESS || payment2.getPaymentStatus()==PAYMENT_STATUS.PENDING ||
                    payment2.getPaymentStatus()==PAYMENT_STATUS.PARKED_PENDING || payment2.getPaymentStatus()==PAYMENT_STATUS.FAILED) {
                refPayment = new PaymentReference(payment2.getSettlementId(), payment2.getTransactionId(),
                        String.valueOf(payment2.getPaymentStatus()));
            } else {
                refPayment = payment2.getPaymentReference();
            }
            validPayment.setPaymentReference(refPayment);
            validPayment.setPaymentStatus(PAYMENT_STATUS.DUPLICATE_REJECTED);
        } else if((payment1.getSettlementId().equals(payment2.getSettlementId()) ||
                payment1.getTransactionId().equals(payment2.getTransactionId())) && payment2!=null && (payment2.getPaymentStatus()!=
                PAYMENT_STATUS.SUCCESS && payment2.getPaymentStatus()!=PAYMENT_STATUS.PENDING
                && payment2.getPaymentStatus()!=PAYMENT_STATUS.WIP && payment2.getPaymentStatus()!=PAYMENT_STATUS.PARKED_PENDING
                && payment2.getPaymentStatus()!=PAYMENT_STATUS.FAILED
                && payment2.getPaymentStatus()!=PAYMENT_STATUS.DUPLICATE_REJECTED
                && payment2.getPaymentStatus()!=PAYMENT_STATUS.DUPLICATE_SETTLEMENT_REJECTED &&
                payment2.getPaymentStatus()!=PAYMENT_STATUS.DUPLICATE_TRANSACTION_REJECTED)) {
            validPayment = payment1;
            PaymentReference refPayment = null;
            if(payment2.getPaymentStatus()== PAYMENT_STATUS.SUCCESS || payment2.getPaymentStatus()==PAYMENT_STATUS.PENDING ||
                    payment2.getPaymentStatus()==PAYMENT_STATUS.PARKED_PENDING) {
                refPayment = new PaymentReference(payment2.getSettlementId(), payment2.getTransactionId(),
                        String.valueOf(payment2.getPaymentStatus()));
            } else {
                refPayment = payment2.getPaymentReference();
            }
            validPayment.setPaymentReference(refPayment);
            validPayment.setPaymentStatus(PAYMENT_STATUS.WIP);
        }
        if(payment1!=null) {
            System.out.println("T :: payment1:- " + payment1.getSettlementId() + ":" + payment1.getTransactionId() + ":" + payment1.getPaymentStatus());
        }
        if(payment2!=null) {
            System.out.println("T :: payment2:- " + payment2.getSettlementId() + ":" + payment2.getTransactionId() + ":" + payment2.getPaymentStatus());
        }
        if(validPayment!=null) {
            System.out.println("T :: validPayment:- " + validPayment.getSettlementId() + ":" + validPayment.getTransactionId() + ":" + validPayment.getPaymentStatus());
        }
        return validPayment;
    }

}
