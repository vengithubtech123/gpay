package com.icici.gpaycommon.pojo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.icici.gpaycommon.dto.PaymentStatusCheckResponse;


public class ResponseStatusCheckUPI implements PaymentStatusCheckResponse {

    @JsonProperty("success")
    private Boolean success;
    @JsonProperty("response")
    private String response;
    @JsonProperty("message")
    private String message;
    @JsonProperty("BankRRN")
    private String bankRRN;
    @JsonProperty("UpiTranlogId")
    private String upiTranlogId;
    @JsonProperty("UserProfile")
    private String userProfile;
    @JsonProperty("SeqNo")
    private String seqNo;
    @JsonProperty("MobileAppData")
    private MobileAppData mobileAppData;
    @JsonProperty("PayerRespCode")
    private String payerRespCode;
    @JsonProperty("PayeeRespCode")
    private String payeeRespCode;
    @JsonProperty("PayerRevRespCode")
    private String payerRevRespCode;
    @JsonProperty("PayeeRevRespCode")
    private String payeeRevRespCode;
    @JsonIgnore
    private int responseCode;
    @JsonIgnore
    private String responseBody;

    public ResponseStatusCheckUPI() {
    }

    public ResponseStatusCheckUPI(Boolean success, String response, String message, String bankRRN, String upiTranlogId, String userProfile, String seqNo, MobileAppData mobileAppData, String payerRespCode, String payeeRespCode, String payerRevRespCode, String payeeRevRespCode) {
        super();
        this.success = success;
        this.response = response;
        this.message = message;
        this.bankRRN = bankRRN;
        this.upiTranlogId = upiTranlogId;
        this.userProfile = userProfile;
        this.seqNo = seqNo;
        this.mobileAppData = mobileAppData;
        this.payerRespCode = payerRespCode;
        this.payeeRespCode = payeeRespCode;
        this.payerRevRespCode = payerRevRespCode;
        this.payeeRevRespCode = payeeRevRespCode;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getBankRRN() {
        return bankRRN;
    }

    public void setBankRRN(String bankRRN) {
        this.bankRRN = bankRRN;
    }

    public String getUpiTranlogId() {
        return upiTranlogId;
    }

    public void setUpiTranlogId(String upiTranlogId) {
        this.upiTranlogId = upiTranlogId;
    }

    public String getUserProfile() {
        return userProfile;
    }

    public void setUserProfile(String userProfile) {
        this.userProfile = userProfile;
    }

    public String getSeqNo() {
        return seqNo;
    }

    public void setSeqNo(String seqNo) {
        this.seqNo = seqNo;
    }

    public MobileAppData getMobileAppData() {
        return mobileAppData;
    }

    public void setMobileAppData(MobileAppData mobileAppData) {
        this.mobileAppData = mobileAppData;
    }

    public String getPayerRespCode() {
        return payerRespCode;
    }

    public void setPayerRespCode(String payerRespCode) {
        this.payerRespCode = payerRespCode;
    }

    public String getPayeeRespCode() {
        return payeeRespCode;
    }

    public void setPayeeRespCode(String payeeRespCode) {
        this.payeeRespCode = payeeRespCode;
    }

    public String getPayerRevRespCode() {
        return payerRevRespCode;
    }

    public void setPayerRevRespCode(String payerRevRespCode) {
        this.payerRevRespCode = payerRevRespCode;
    }

    public String getPayeeRevRespCode() {
        return payeeRevRespCode;
    }

    public void setPayeeRevRespCode(String payeeRevRespCode) {
        this.payeeRevRespCode = payeeRevRespCode;
    }

    public void setResponseCode(int responseCode) {
        this.responseCode = responseCode;
    }

    public void setResponseBody(String responseBody) {
        this.responseBody = responseBody;
    }

    @Override
    public int getResponseCode() {
        return this.responseCode;
    }

    @Override
    public String getResponseBody() {
        return this.responseBody;
    }
}
