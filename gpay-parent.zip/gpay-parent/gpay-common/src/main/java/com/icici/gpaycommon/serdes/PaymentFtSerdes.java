package com.icici.gpaycommon.serdes;

import com.icici.gpaycommon.deserializer.PaymentDeserializer;
import com.icici.gpaycommon.deserializer.PaymentFtDeserializer;
import com.icici.gpaycommon.dto.Payment;
import com.icici.gpaycommon.serializer.PaymentFtSerializer;
import com.icici.gpaycommon.serializer.PaymentSerializer;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serdes;

/**
 * @author aditya_shekhar on 1/20/2024
 */
public final class PaymentFtSerdes{

    private PaymentFtSerdes() {}
    public static Serde<Payment> serde() {
        PaymentFtSerializer<Payment> serializer = new PaymentFtSerializer<>();
        PaymentFtDeserializer<Payment> deserializer = new PaymentFtDeserializer<>(Payment.class);
        return Serdes.serdeFrom(serializer, deserializer);
    }
}
