package com.icici.gpaycommon.pojo;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author aditya_shekhar on 4/5/2024
 */
public class NeftStatus {
    @JsonProperty("messageType")
    public String messageType;
    @JsonProperty("srNo")
    public String srNo;
    @JsonProperty("failureReason")
    public String failureReason;
    @JsonProperty("processingDate")
    public String processingDate;
    @JsonProperty("transStatus")
    public String transStatus;
    @JsonProperty("paymentType")
    public String paymentType;

    public NeftStatus() {
    }

    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    public String getSrNo() {
        return srNo;
    }

    public void setSrNo(String srNo) {
        this.srNo = srNo;
    }

    public String getFailureReason() {
        return failureReason;
    }

    public void setFailureReason(String failureReason) {
        this.failureReason = failureReason;
    }

    public String getProcessingDate() {
        return processingDate;
    }

    public void setProcessingDate(String processingDate) {
        this.processingDate = processingDate;
    }

    public String getTransStatus() {
        return transStatus;
    }

    public void setTransStatus(String transStatus) {
        this.transStatus = transStatus;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }
}