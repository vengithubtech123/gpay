package com.icici.gpaycommon.pojo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.icici.gpaycommon.dto.PaymentResponse;

public class PaymentResponseNEFT implements PaymentResponse {

    @JsonProperty("STATUS")
    private String status;
    @JsonProperty("RESPONSE")
    private String response;
    @JsonProperty("ERRORCODE")
    private String errorCode;
    @JsonProperty("RESPONSECODE")
    private String respCode;
    @JsonProperty("MESSAGE")
    private String message;
    @JsonProperty("REQID")
    private String reqId; //Only for Success
    @JsonProperty("UNIQUEID")
    private String uniqueId;
    @JsonProperty("UTR")
    private String utr;
    @JsonIgnore
    private int responseCode;
    @JsonIgnore
    private String responseBody;

    public PaymentResponseNEFT() {
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getRespCode() {
        return respCode;
    }

    public void setRespCode(String respCode) {
        this.respCode = respCode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public int getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(int responseCode) {
        this.responseCode = responseCode;
    }

    @Override
    public String getResponseBody() {
        return responseBody;
    }

    public void setResponseBody(String responseBody) {
        this.responseBody = responseBody;
    }

    public String getReqId() {
        return reqId;
    }

    public void setReqId(String reqId) {
        this.reqId = reqId;
    }

    public String getUniqueId() {
        return uniqueId;
    }

    public void setUniqueId(String uniqueId) {
        this.uniqueId = uniqueId;
    }

    public String getUtr() {
        return utr;
    }

    public void setUtr(String utr) {
        this.utr = utr;
    }
}
