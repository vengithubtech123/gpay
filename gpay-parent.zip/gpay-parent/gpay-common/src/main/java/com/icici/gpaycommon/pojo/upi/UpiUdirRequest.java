package com.icici.gpaycommon.pojo.upi;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.icici.gpaycommon.dto.PaymentStatusCheckRequest;
import com.icici.gpaycommon.dto.PaymentStatusCheckResponse;

/**
 * @author aditya_shekhar on 3/27/2024
 */
public class UpiUdirRequest implements PaymentStatusCheckRequest {

    @JsonProperty("seq-no")
    String seqNo;
    @JsonProperty("channel-code")
    String channelCode;
    @JsonProperty("ori-seq-no")
    String oriSeqNo;
    @JsonProperty("mobile")
    String mobile;
    @JsonProperty("profile-id")
    String profileId;
    @JsonProperty("device-id")
    String deviceId;

    public UpiUdirRequest() {
        //TO-DO
    }
    public UpiUdirRequest(String seqNo, String channelCode, String oriSeqNo, String mobile, String profileId, String deviceId) {
        this.seqNo = seqNo;
        this.channelCode = channelCode;
        this.oriSeqNo = oriSeqNo;
        this.mobile = mobile;
        this.profileId = profileId;
        this.deviceId = deviceId;
    }

    public String getSeqNo() {
        return seqNo;
    }

    public void setSeqNo(String seqNo) {
        this.seqNo = seqNo;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public String getOriSeqNo() {
        return oriSeqNo;
    }

    public void setOriSeqNo(String oriSeqNo) {
        this.oriSeqNo = oriSeqNo;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

}
