package com.icici.gpaycommon.deserializer;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.icici.gpaycommon.dto.*;
import com.icici.gpaycommon.pojo.*;
import org.apache.kafka.common.errors.SerializationException;
import org.apache.kafka.common.serialization.Deserializer;

import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.Map;

import static com.icici.gpaycommon.adapter.InterfaceSerializer.interfaceSerializer;

/**
 * @author aditya_shekhar on 1/20/2024
 */
public class PaymentDeserializer<T> implements Deserializer<T> {

    private final Gson gson = new GsonBuilder()
            .registerTypeAdapter(PaymentRequest.class, interfaceSerializer(PaymentRequestUPI.class))
            .registerTypeAdapter(PaymentResponse.class, interfaceSerializer(PaymentResponseUPI.class))
            .registerTypeAdapter(PaymentStatusCheckRequest.class, interfaceSerializer(RequestStatusCheckUPI.class))
            .registerTypeAdapter(PaymentStatusCheckResponse.class, interfaceSerializer(ResponseStatusCheckUPI.class))
            /*.registerTypeAdapter(PaymentRequest.class, interfaceSerializer(PaymentRequestIMPS.class))
            .registerTypeAdapter(PaymentRequest.class, interfaceSerializer(PaymentRequestUPI.class))
            .registerTypeAdapter(PaymentRequest.class, interfaceSerializer(PaymentRequestNEFT.class))
            .registerTypeAdapter(PaymentRequest.class, interfaceSerializer(PaymentRequestRTGS.class))
            .registerTypeAdapter(PaymentResponse.class, interfaceSerializer(PaymentResponseIMPS.class))
            .registerTypeAdapter(PaymentResponse.class, interfaceSerializer(PaymentResponseUPI.class))
            .registerTypeAdapter(PaymentResponse.class, interfaceSerializer(PaymentResponseNEFT.class))
            .registerTypeAdapter(PaymentResponse.class, interfaceSerializer(PaymentResponseRTGS.class))*/
            .create();

    private Class<T> destinationClass;
    private Type reflectionTypeToken;

    public PaymentDeserializer(Class<T> destinationClass) {
        this.destinationClass = destinationClass;
    }

    public PaymentDeserializer(Type reflectionTypeToken) {
        this.reflectionTypeToken = reflectionTypeToken;
    }

    @Override
    public void configure(Map<String, ?> props, boolean isKey) {
        // nothing to do
    }

    @Override
    public T deserialize(String topic, byte[] bytes) {
        if (bytes == null)
            return null;

        try {
            Type type = destinationClass != null ? destinationClass : reflectionTypeToken;
            return gson.fromJson(new String(bytes, StandardCharsets.UTF_8), type);
        } catch (Exception e) {
            throw new SerializationException("Error deserializing message", e);
        }
    }

    @Override
    public void close() {
        // nothing to do
    }
}