package com.icici.gpaycommon.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.StandardCopyOption;

/**
 * @author aditya_shekhar on 1/25/2024
 */
public class FileUtil {

    public static void inputStreamToFile(InputStream inputStream, String fileName, String path) throws IOException {
        File targetFile = new File(path +  "/" +fileName);
        java.nio.file.Files.copy(inputStream, targetFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        //IOUtils.closeQuietly(initialStream);
    }
}
