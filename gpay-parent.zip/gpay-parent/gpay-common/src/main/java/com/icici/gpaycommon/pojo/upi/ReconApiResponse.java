package com.icici.gpaycommon.pojo.upi;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ReconApiResponse{
    @JsonProperty("headers")
    private Headers headers;

    public Headers getHeaders() {
        return this.headers;
    }

    public void setHeaders(Headers headers) {
        this.headers = headers;
    }
}
