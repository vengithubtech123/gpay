package com.icici.gpaycommon.pojo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.icici.gpaycommon.dto.PaymentResponse;

public class PaymentResponseIMPS implements PaymentResponse {

    @JsonProperty("ActCode")
    private String actCode;
    @JsonProperty("Response")
    private String response;
    @JsonProperty("BankRRN")
    private String bankRRN;
    @JsonProperty("BeneName")
    private String beneName;
    @JsonProperty("success")
    private Boolean success;
    @JsonProperty("TransRefNo")
    private String transRefNo;

    @JsonIgnore
    private int responseCode;
    @JsonIgnore
    private String responseBody;

    public PaymentResponseIMPS() {
    }

    public PaymentResponseIMPS(String actCode, String response, String bankRRN, String beneName, Boolean success, String transRefNo) {
        super();
        this.actCode = actCode;
        this.response = response;
        this.bankRRN = bankRRN;
        this.beneName = beneName;
        this.success = success;
        this.transRefNo = transRefNo;
    }

    public String getActCode() {
        return actCode;
    }

    public void setActCode(String actCode) {
        this.actCode = actCode;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public String getBankRRN() {
        return bankRRN;
    }

    public void setBankRRN(String bankRRN) {
        this.bankRRN = bankRRN;
    }

    public String getBeneName() {
        return beneName;
    }

    public void setBeneName(String beneName) {
        this.beneName = beneName;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public String getTransRefNo() {
        return transRefNo;
    }

    public void setTransRefNo(String transRefNo) {
        this.transRefNo = transRefNo;
    }

    public void setResponseCode(int responseCode) {
        this.responseCode = responseCode;
    }

    @Override
    public int getResponseCode() {
        return this.responseCode;
    }

    public void setResponseBody(String responseBody) {
        this.responseBody = responseBody;
    }

    @Override
    public String getResponseBody() {
        return this.responseBody;
    }
}
