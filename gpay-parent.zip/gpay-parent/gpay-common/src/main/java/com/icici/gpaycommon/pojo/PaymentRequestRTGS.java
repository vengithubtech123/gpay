package com.icici.gpaycommon.pojo;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.icici.gpaycommon.dto.PaymentRequest;

public class PaymentRequestRTGS implements PaymentRequest {

    @JsonProperty("AGGRID")
    private String aggrid;
    @JsonProperty("CORPID")
    private String corpid;
    @JsonProperty("USERID")
    private String userid;
    @JsonProperty("URN")
    private String urn;
    @JsonProperty("AGGRNAME")
    private String aggrname;
    @JsonProperty("UNIQUEID")
    private String uniqueid;
    @JsonProperty("DEBITACC")
    private String debitacc;
    @JsonProperty("CREDITACC")
    private String creditacc;
    @JsonProperty("IFSC")
    private String ifsc;
    @JsonProperty("AMOUNT")
    private String amount;
    @JsonProperty("CURRENCY")
    private String currency;
    @JsonProperty("TXNTYPE")
    private String txntype;
    @JsonProperty("PAYEENAME")
    private String payeename;
    @JsonProperty("REMARKS")
    private String remarks;
    @JsonProperty("WORKFLOW_REQD")
    private String workflowReqd;

    /**
     * No args constructor for use in serialization
     *
     */
    public PaymentRequestRTGS() {
    }

    /**
     *
     * @param amount
     * @param payeename
     * @param corpid
     * @param workflowReqd
     * @param aggrname
     * @param userid
     * @param aggrid
     * @param urn
     * @param debitacc
     * @param txntype
     * @param currency
     * @param creditacc
     * @param ifsc
     * @param uniqueid
     * @param remarks
     */
    public PaymentRequestRTGS(String aggrid, String corpid, String userid, String urn, String aggrname, String uniqueid, String debitacc, String creditacc, String ifsc, String amount, String currency, String txntype, String payeename, String remarks, String workflowReqd) {
        super();
        this.aggrid = aggrid;
        this.corpid = corpid;
        this.userid = userid;
        this.urn = urn;
        this.aggrname = aggrname;
        this.uniqueid = uniqueid;
        this.debitacc = debitacc;
        this.creditacc = creditacc;
        this.ifsc = ifsc;
        this.amount = amount;
        this.currency = currency;
        this.txntype = txntype;
        this.payeename = payeename;
        this.remarks = remarks;
        this.workflowReqd = workflowReqd;
    }

    public String getAggrid() {
        return aggrid;
    }

    public void setAggrid(String aggrid) {
        this.aggrid = aggrid;
    }

    public String getCorpid() {
        return corpid;
    }

    public void setCorpid(String corpid) {
        this.corpid = corpid;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getUrn() {
        return urn;
    }

    public void setUrn(String urn) {
        this.urn = urn;
    }

    public String getAggrname() {
        return aggrname;
    }

    public void setAggrname(String aggrname) {
        this.aggrname = aggrname;
    }

    public String getUniqueid() {
        return uniqueid;
    }

    public void setUniqueid(String uniqueid) {
        this.uniqueid = uniqueid;
    }

    public String getDebitacc() {
        return debitacc;
    }

    public void setDebitacc(String debitacc) {
        this.debitacc = debitacc;
    }

    public String getCreditacc() {
        return creditacc;
    }

    public void setCreditacc(String creditacc) {
        this.creditacc = creditacc;
    }

    public String getIfsc() {
        return ifsc;
    }

    public void setIfsc(String ifsc) {
        this.ifsc = ifsc;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getTxntype() {
        return txntype;
    }

    public void setTxntype(String txntype) {
        this.txntype = txntype;
    }

    public String getPayeename() {
        return payeename;
    }

    public void setPayeename(String payeename) {
        this.payeename = payeename;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getWorkflowReqd() {
        return workflowReqd;
    }

    public void setWorkflowReqd(String workflowReqd) {
        this.workflowReqd = workflowReqd;
    }

}