package com.icici.gpaycommon.pojo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.icici.gpaycommon.dto.PaymentResponse;

public class PaymentResponseErrorUPI implements PaymentResponse {

    @JsonProperty("fault")
    private Fault fault;

    @JsonIgnore
    private int responseCode;
    @JsonIgnore
    private String responseBody;

    /**
     * No args constructor for use in serialization
     *
     */
    public PaymentResponseErrorUPI() {
    }

    /**
     *
     * @param fault
     */
    public PaymentResponseErrorUPI(Fault fault) {
        super();
        this.fault = fault;
    }

    public Fault getFault() {
        return fault;
    }

    public void setFault(Fault fault) {
        this.fault = fault;
    }

    @Override
    public int getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(int responseCode) {
        this.responseCode = responseCode;
    }

    public void setResponseBody(String responseBody) {
        this.responseBody = responseBody;
    }

    @Override
    public String getResponseBody() {
        return this.responseBody;
    }
}


