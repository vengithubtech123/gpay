package com.icici.gpaycommon.serdes;

import com.icici.gpaycommon.deserializer.PaymentDeserializer;
import com.icici.gpaycommon.dto.Payment;
import com.icici.gpaycommon.serializer.PaymentSerializer;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serdes;

/**
 * @author aditya_shekhar on 1/20/2024
 */
public final class PaymentSerdes{

    private PaymentSerdes() {}
    public static Serde<Payment> serde() {
        PaymentSerializer<Payment> serializer = new PaymentSerializer<>();
        PaymentDeserializer<Payment> deserializer = new PaymentDeserializer<>(Payment.class);
        return Serdes.serdeFrom(serializer, deserializer);
    }
}
