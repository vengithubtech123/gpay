package com.icici.gpaycommon.exception;

/**
 * @author aditya_shekhar on 1/20/2024
 */
public class ProcessorException extends Throwable {

    private String message;

    public ProcessorException(String message) {
        super(message);
        this.message = message;
    }

    @Override
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
