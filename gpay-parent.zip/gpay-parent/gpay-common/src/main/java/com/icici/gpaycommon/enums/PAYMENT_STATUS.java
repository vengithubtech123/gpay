package com.icici.gpaycommon.enums;

/**
 * @author aditya_shekhar on 1/20/2024
 */
public enum PAYMENT_STATUS {

    WIP,
    SUCCESS,
    PENDING,
    FAILED,
    FAILED_TIMEOUT,
    DUPLICATE_REJECTED,
    DUPLICATE_SETTLEMENT_REJECTED,
    DUPLICATE_TRANSACTION_REJECTED,
    SCHEMA_REJECTED,
    STATUS_UNKNOWN,
    TIMEOUT,
    PARKED_PENDING,
    // STALE_REJECTED to be stopped further payment //change to retries_exhausted
    NOT_FOUND
}
