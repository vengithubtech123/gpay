package com.icici.gpaycommon.pojo;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.icici.gpaycommon.dto.PaymentStatusCheckRequest;


public class RequestStatusCheckUPI implements PaymentStatusCheckRequest {

    @JsonProperty("seq-no")
    private String seqNo;
    @JsonProperty("channel-code")
    private String channelCode;
    @JsonProperty("ori-seq-no")
    private String oriSeqNo;
    @JsonProperty("mobile")
    private String mobile;
    @JsonProperty("profile-id")
    private String profileId;
    @JsonProperty("device-id")
    private String deviceId;

    /**
     * No args constructor for use in serialization
     *
     */
    public RequestStatusCheckUPI() {
    }

    public RequestStatusCheckUPI(String seqNo, String channelCode, String oriSeqNo, String mobile, String profileId, String deviceId) {
        super();
        this.seqNo = seqNo;
        this.channelCode = channelCode;
        this.oriSeqNo = oriSeqNo;
        this.mobile = mobile;
        this.profileId = profileId;
        this.deviceId = deviceId;
    }

    public String getSeqNo() {
        return seqNo;
    }

    public void setSeqNo(String seqNo) {
        this.seqNo = seqNo;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public String getOriSeqNo() {
        return oriSeqNo;
    }

    public void setOriSeqNo(String oriSeqNo) {
        this.oriSeqNo = oriSeqNo;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

}
