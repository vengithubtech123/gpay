package com.icici.gpaycommon.dto;

import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.icici.gpaycommon.enums.PAYMENT_STATUS;
import com.icici.gpaycommon.enums.PAYMENT_TYPE;
import com.icici.gpaycommon.pojo.*;

import java.util.Date;
import java.util.UUID;

/**
 * @author aditya_shekhar on 1/20/2024
 */
public class Payment {

    private String uuid;
    private String settlementId;
    private String transactionId;
    private String priorityCode;
    private PAYMENT_TYPE paymentType;
    private PAYMENT_STATUS paymentStatus;
    private PAYMENT_STATUS previousPaymentStatus;
    @JsonTypeInfo(use=JsonTypeInfo.Id.CLASS, include=JsonTypeInfo.As.PROPERTY, property="@class")
    private PaymentRequest paymentRequest;
    @JsonTypeInfo(use=JsonTypeInfo.Id.CLASS, include=JsonTypeInfo.As.PROPERTY, property="@class")
    private PaymentResponse paymentResponse;
    private Date paymentReqDateTime;
    private Date paymentRespDateTime;
    private PaymentRetry paymentRetry = null;
    private PaymentReference paymentReference;
    private String paymentReqString;

    public Payment() {
    }

    public Payment(String settlementId, String priorityCode) {
        paymentReqDateTime = new Date();
        this.uuid = UUID.randomUUID().toString() + settlementId;
        this.settlementId = settlementId;
        this.priorityCode = priorityCode;
        switch(priorityCode) {
            case "01000":
                paymentType = PAYMENT_TYPE.IMPS;
                break;
            case "10000":
                paymentType = PAYMENT_TYPE.UPI;
                break;
            case "00100":
                paymentType = PAYMENT_TYPE.NEFT;
                break;
            case "00010":
                paymentType = PAYMENT_TYPE.RTGS;
                break;
            case "00001":
                paymentType = PAYMENT_TYPE.FT;
            default:
                this.paymentRequest = null;
        }
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getSettlementId() {
        return settlementId;
    }

    public void setSettlementId(String settlementId) {
        this.settlementId = settlementId;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getPriorityCode() {
        return priorityCode;
    }

    public void setPriorityCode(String priorityCode) {
        this.priorityCode = priorityCode;
    }

    public PAYMENT_TYPE getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(PAYMENT_TYPE paymentType) {
        this.paymentType = paymentType;
    }

    public PAYMENT_STATUS getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(PAYMENT_STATUS paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public PaymentRequest getPaymentRequest() {
        return paymentRequest;
    }

    public void setPaymentRequest(PaymentRequest paymentRequest) {
        this.paymentRequest = paymentRequest;
    }

    public Date getPaymentReqDateTime() {
        return paymentReqDateTime;
    }

    public void setPaymentReqDateTime(Date paymentReqDateTime) {
        this.paymentReqDateTime = paymentReqDateTime;
    }

    public Date getPaymentRespDateTime() {
        return paymentRespDateTime;
    }

    public void setPaymentRespDateTime(Date paymentRespDateTime) {
        this.paymentRespDateTime = paymentRespDateTime;
    }

    public void setPaymentRequest(String paymentRequestString) {
        //this.paymentReqString = paymentRequestString;
        ObjectMapper om = new ObjectMapper();
        om.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, false);
        om.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        om.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        try {
            JsonNode jsonNode = om.readValue(paymentRequestString, JsonNode.class);
            this.paymentReqString = jsonNode.toString();
            switch(paymentType){
                case IMPS:
                    PaymentRequestIMPS transactionIMPS = om.readValue(paymentRequestString, PaymentRequestIMPS.class);
                    this.setPaymentRequest(transactionIMPS);
                    this.transactionId = transactionIMPS.getTranRefNo();
                    break;
                case UPI:
                    PaymentRequestUPI transactionUPI = om.readValue(paymentRequestString, PaymentRequestUPI.class);
                    this.setPaymentRequest(transactionUPI);
                    this.transactionId = transactionUPI.getSeqNo();
                    break;
                case NEFT:
                    PaymentRequestNEFT paymentRequestNEFT = om.readValue(paymentRequestString, PaymentRequestNEFT.class);
                    this.setPaymentRequest(paymentRequestNEFT);
                    this.transactionId = paymentRequestNEFT.getTranRefNo();
                    break;
                case RTGS:
                    PaymentRequestRTGS paymentRequestRTGS = om.readValue(paymentRequestString, PaymentRequestRTGS.class);
                    this.setPaymentRequest(paymentRequestRTGS);
                    this.transactionId = paymentRequestRTGS.getUniqueid();
                    break;
                case FT:
                    PaymentRequestFT paymentRequestFT = om.readValue(paymentRequestString, PaymentRequestFT.class);
                    this.setPaymentRequest(paymentRequestFT);
                    this.transactionId = paymentRequestFT.getTranRefNo();
                    break;
                default:
                    this.paymentRequest = null;
            }
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    public PaymentResponse getPaymentResponse() {
        return paymentResponse;
    }

    public void setPaymentResponse(PaymentResponse paymentResponse) {
        this.paymentResponse = paymentResponse;
    }

    public void setPaymentResponseFromSwitch(PaymentResponse paymentResponse) {
        ObjectMapper om = new ObjectMapper();
        //om.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, false);
        //om.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        //om.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        String responseBody = paymentResponse.getResponseBody();
        int responseCode = paymentResponse.getResponseCode();
        try {
            switch(paymentType){
                case IMPS:
                    if(responseCode==200) {
                        PaymentResponseIMPS transactionIMPS = om.readValue(responseBody, PaymentResponseIMPS.class);
                        transactionIMPS.setResponseBody(responseBody);
                        transactionIMPS.setResponseCode(200);
                        this.setPaymentResponse(transactionIMPS);
                        // failure: 36, 39, 15
                    } else if(responseCode==404) {
                        PaymentResponseErrorIMPS error = new PaymentResponseErrorIMPS();
                        error.setResponseBody(responseBody);
                        error.setResponseCode(404);
                        this.setPaymentResponse(error);
                    } else if(responseCode==500) {
                        BadGateway errorIMPS = new BadGateway();
                        errorIMPS.setFault(responseBody);
                        errorIMPS.setResponseBody(responseBody);
                        errorIMPS.setResponseCode(500);
                        this.setPaymentResponse(errorIMPS);
                    }
                    break;
                case UPI:
                    if(responseCode==200) {
                        PaymentResponseUPI transactionUPI = om.readValue(responseBody, PaymentResponseUPI.class);
                        transactionUPI.setResponseBody(responseBody);
                        transactionUPI.setResponseCode(200);
                        this.setPaymentResponse(transactionUPI);
                        // failure: 36, 39, 15
                    } else if(responseCode==404) {
                        PaymentResponseErrorUPI error = new PaymentResponseErrorUPI();
                        error.setResponseBody(responseBody);
                        error.setResponseCode(404);
                        this.setPaymentResponse(error);
                    } else if(responseCode==500) {
                        BadGateway errorUPI = new BadGateway();
                        errorUPI.setFault(responseBody);
                        errorUPI.setResponseBody(responseBody);
                        errorUPI.setResponseCode(500);
                        this.setPaymentResponse(errorUPI);
                    }
                    break;
                case NEFT:
                    if(responseCode==200) {
                        PaymentResponseNEFT transactionNEFT = om.readValue(responseBody, PaymentResponseNEFT.class);
                        transactionNEFT.setResponseBody(responseBody);
                        transactionNEFT.setResponseCode(200);
                        this.setPaymentResponse(transactionNEFT);
                        // failure: 36, 39, 15
                    } else if(responseCode==404) {
                        PaymentResponseErrorNEFT error = new PaymentResponseErrorNEFT();
                        error.setResponseBody(responseBody);
                        error.setResponseCode(404);
                        this.setPaymentResponse(error);
                    } else if(responseCode==500) {
                        BadGateway errorNEFT = new BadGateway();
                        errorNEFT.setFault(responseBody);
                        errorNEFT.setResponseBody(responseBody);
                        errorNEFT.setResponseCode(500);
                        this.setPaymentResponse(errorNEFT);
                    }
                    break;
                case RTGS:
                    if(responseCode==200) {
                        PaymentResponseRTGS transactionRTGS = om.readValue(responseBody, PaymentResponseRTGS.class);
                        transactionRTGS.setResponseBody(responseBody);
                        transactionRTGS.setResponseCode(200);
                        this.setPaymentResponse(transactionRTGS);
                        // failure: 36, 39, 15
                    } else if(responseCode==404) {
                        PaymentResponseErrorRTGS error = new PaymentResponseErrorRTGS();
                        error.setResponseBody(responseBody);
                        error.setResponseCode(404);
                        this.setPaymentResponse(error);
                    } else if(responseCode==500) {
                        BadGateway errorRTGS = new BadGateway();
                        errorRTGS.setFault(responseBody);
                        errorRTGS.setResponseBody(responseBody);
                        errorRTGS.setResponseCode(500);
                        this.setPaymentResponse(errorRTGS);
                    }
                    break;
                default:
                    this.paymentResponse = null;
            }
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    public PaymentRetry getPaymentRetry() {
        return paymentRetry;
    }

    public void setPaymentRetry(PaymentRetry paymentRetry) {
        this.paymentRetry = paymentRetry;
    }

    public PaymentReference getPaymentReference() {
        return paymentReference;
    }

    public void setPaymentReference(PaymentReference paymentReference) {
        this.paymentReference = paymentReference;
    }

    public String getPaymentReqString() {
        return paymentReqString;
    }

    public void setPaymentReqString(String paymentReqString) {
        this.paymentReqString = paymentReqString;
    }

    public PAYMENT_STATUS getPreviousPaymentStatus() {
        return previousPaymentStatus;
    }

    public void setPreviousPaymentStatus(PAYMENT_STATUS previousPaymentStatus) {
        this.previousPaymentStatus = previousPaymentStatus;
    }

    /*
    @Override
    public String toString() {
        //String json = new Gson().toJson(this);
        JsonElement jsonElement = new Gson().toJsonTree(this);//.getAsJsonObject();
        JsonObject jsonObj = jsonElement.getAsJsonObject();
        JsonElement jsonPaymentReq = null;
        switch(paymentType) {
            case IMPS:
                PaymentRequestIMPS transactionIMPS = (PaymentRequestIMPS) this.getPaymentRequest();
                jsonPaymentReq = new Gson().toJsonTree(transactionIMPS).getAsJsonObject();
                jsonObj.add("paymentRequest", jsonPaymentReq);
                break;
            case UPI:
                PaymentRequestUPI transactionUPI = (PaymentRequestUPI) this.getPaymentRequest();
                jsonPaymentReq = new Gson().toJsonTree(transactionUPI).getAsJsonObject();
                jsonObj.add("paymentRequest", jsonPaymentReq);
                break;
            case NEFT:
                PaymentRequestNEFT paymentRequestNEFT = (PaymentRequestNEFT) this.getPaymentRequest();
                jsonPaymentReq = new Gson().toJsonTree(paymentRequestNEFT).getAsJsonObject();
                jsonObj.add("paymentRequest", jsonPaymentReq);
                break;
            case RTGS:
                PaymentRequestRTGS paymentRequestRTGS = (PaymentRequestRTGS) this.getPaymentRequest();
                jsonPaymentReq = new Gson().toJsonTree(paymentRequestRTGS).getAsJsonObject();
                jsonObj.add("paymentRequest", jsonPaymentReq);
                break;
            default:
                // Do Nothing
        }
        return jsonObj.getAsString();
    }
*/

}
