package com.icici.gpaycommon.pojo.upi;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Headers{
    /*{"recon-api-response":{"headers":{"message-type":"1004","proc-code":"555001","channel-code":"mobile","stan":"STAN000004",
    "response-code":"0005","response-message":"Record not found."}}}*/

    @JsonProperty("response-message")
    String responseMessage;
    @JsonProperty("response-code")
    String responseCode;
    @JsonProperty("stan")
    String stan;
    @JsonProperty("channel-code")
    String channelCode;
    @JsonProperty("proc-code")
    String procCode;
    @JsonProperty("message-type")
    String messageType;

    public String getMessageType() {
        return this.messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    public String getProcCode() {
        return this.procCode;
    }

    public void setProcCode(String procCode) {
        this.procCode = procCode;
    }

    public String getChannelCode() {
        return this.channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public String getStan() {
        return this.stan;
    }

    public void setStan(String stan) {
        this.stan = stan;
    }

    public String getResponseCode() {
        return this.responseCode;
    }

    public void setResponseCode(String responseCode) {
        this.responseCode = responseCode;
    }

    public String getResponseMessage() {
        return this.responseMessage;
    }

    public void setResponseMessage(String responseMessage) {
        this.responseMessage = responseMessage;
    }
}
