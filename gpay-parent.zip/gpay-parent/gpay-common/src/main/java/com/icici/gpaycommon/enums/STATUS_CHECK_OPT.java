package com.icici.gpaycommon.enums;

/**
 * @author aditya_shekhar on 3/28/2024
 */
public enum STATUS_CHECK_OPT {
    UPI_UDIR, RECON360;
}
