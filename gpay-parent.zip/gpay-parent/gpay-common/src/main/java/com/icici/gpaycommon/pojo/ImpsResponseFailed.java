package com.icici.gpaycommon.pojo;

import com.fasterxml.jackson.annotation.JsonProperty;


public class ImpsResponseFailed {

    @JsonProperty("CheckStatusCode")
    private String checkStatusCode;
    @JsonProperty("CheckStatusMessage")
    private String checkStatusMessage;
    @JsonProperty("ActCode")
    private String actCode;
    @JsonProperty("Response")
    private String response;
    @JsonProperty("BankRRN")
    private String bankRRN;
    @JsonProperty("BeneName")
    private String beneName;
    @JsonProperty("TranRefNo")
    private String tranRefNo;

    /**
     * No args constructor for use in serialization
     *
     */
    public ImpsResponseFailed() {
    }

    /**
     *
     * @param actCode
     * @param beneName
     * @param tranRefNo
     * @param checkStatusCode
     * @param response
     * @param bankRRN
     * @param checkStatusMessage
     */
    public ImpsResponseFailed(String checkStatusCode, String checkStatusMessage, String actCode, String response, String bankRRN, String beneName, String tranRefNo) {
        super();
        this.checkStatusCode = checkStatusCode;
        this.checkStatusMessage = checkStatusMessage;
        this.actCode = actCode;
        this.response = response;
        this.bankRRN = bankRRN;
        this.beneName = beneName;
        this.tranRefNo = tranRefNo;
    }

    public String getCheckStatusCode() {
        return checkStatusCode;
    }

    public void setCheckStatusCode(String checkStatusCode) {
        this.checkStatusCode = checkStatusCode;
    }

    public String getCheckStatusMessage() {
        return checkStatusMessage;
    }

    public void setCheckStatusMessage(String checkStatusMessage) {
        this.checkStatusMessage = checkStatusMessage;
    }

    public String getActCode() {
        return actCode;
    }

    public void setActCode(String actCode) {
        this.actCode = actCode;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public String getBankRRN() {
        return bankRRN;
    }

    public void setBankRRN(String bankRRN) {
        this.bankRRN = bankRRN;
    }

    public String getBeneName() {
        return beneName;
    }

    public void setBeneName(String beneName) {
        this.beneName = beneName;
    }

    public String getTranRefNo() {
        return tranRefNo;
    }

    public void setTranRefNo(String tranRefNo) {
        this.tranRefNo = tranRefNo;
    }

}
