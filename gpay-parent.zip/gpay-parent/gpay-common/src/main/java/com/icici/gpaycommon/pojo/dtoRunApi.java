/*
package com.icici.gpaycommon.pojo;

import com.fasterxml.jackson.core.JsonProcessingException;
import okhttp3.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;

public class dtoRunApi {

    public static void main(String[] args) throws JsonProcessingException {
        // Create an instance of OkHttpClient
        OkHttpClient client = new OkHttpClient();

        // Create an instance of ObjectMapper for JSON serialization/deserialization
        ObjectMapper objectMapper = new ObjectMapper();

        // Replace this with your actual JSON payload
        String jsonPayload = "{" +
                " \"AGGRID\": \"TXBCOMP0054\"," +
                " \"CORPID\": \"SESPRODUCT\"," +
                " \"USERID\": \"389018\"," +
                " \"URN\": \"1885e35c-6291-4791-bca6-5d93452e4870\"," +
                " \"UNIQUEID\": \"202401081032010\"" +
                "}";
        RequestStatusCheckNEFT abc = objectMapper.readValue(jsonPayload, RequestStatusCheckNEFT.class);
        System.out.println("request: "+abc);
        // Replace this with your API endpoint URL
        String apiUrl = "https://uat-onprem-dmz-hybrid.icicibank.com/dedupee_status/neft";

        // Build the request
        RequestBody requestBody = RequestBody.create(MediaType.parse("application/json"), jsonPayload);
        Request request = new Request.Builder()
                .url(apiUrl)
                .post(requestBody)
                .build();

        // Execute the request and handle the response
        try (Response response = client.newCall(request).execute()) {
            if (response.isSuccessful()) {
                // Read the response body as a string
                String responseBody = response.body().string();
                try{
                    // Convert the JSON response to an object using Jackson
                    PaymentResponseNEFT responseObject = objectMapper.readValue(responseBody, PaymentResponseNEFT.class);
                    // Print the converted object
                    System.out.println("Response Object: " + responseObject);
                } catch (Exception e){
                    System.out.println("Error:" +e);
                }

            } else {
                System.out.println("Error: " + response.code() + " - " + response.message());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}*/
