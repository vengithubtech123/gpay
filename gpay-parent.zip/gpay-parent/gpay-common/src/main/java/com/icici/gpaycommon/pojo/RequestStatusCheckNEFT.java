package com.icici.gpaycommon.pojo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.icici.gpaycommon.dto.PaymentStatusCheckRequest;

public class RequestStatusCheckNEFT implements PaymentStatusCheckRequest {

    @JsonProperty("aggrid")
    private String aggrid;
    @JsonProperty("date")
    private String date;
    @JsonProperty("uniqueid")
    private String uniqueid;

    public RequestStatusCheckNEFT() {
    }

    public RequestStatusCheckNEFT(String aggrid, String date, String uniqueid) {
        this.aggrid = aggrid;
        this.date = date;
        this.uniqueid = uniqueid;
    }

    public String getAggrid() {
        return aggrid;
    }

    public void setAggrid(String aggrid) {
        this.aggrid = aggrid;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getUniqueid() {
        return uniqueid;
    }

    public void setUniqueid(String uniqueid) {
        this.uniqueid = uniqueid;
    }
}