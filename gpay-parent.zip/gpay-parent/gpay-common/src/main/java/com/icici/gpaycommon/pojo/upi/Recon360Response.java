package com.icici.gpaycommon.pojo.upi;

// import com.fasterxml.jackson.databind.ObjectMapper; // version 2.11.1
// import com.fasterxml.jackson.annotation.JsonProperty; // version 2.11.1
/* ObjectMapper om = new ObjectMapper();
Root root = om.readValue(myJsonString, Root.class); */

import com.fasterxml.jackson.annotation.JsonProperty;
import com.icici.gpaycommon.dto.PaymentStatusCheckResponse;

public class Recon360Response implements PaymentStatusCheckResponse {
    @JsonProperty("recon-api-response")
    private ReconApiResponse reconApiResponse;

    private int responseCode;
    private String responseBody;

    public ReconApiResponse getReconApiResponse() {
        return this.reconApiResponse;
    }
    public void setReconApiResponse(ReconApiResponse reconApiResponse) {
        this.reconApiResponse = reconApiResponse;
    }

    @Override
    public int getResponseCode() {
        return responseCode;
    }

    @Override
    public String getResponseBody() {
        return responseBody;
    }

    public void setResponseCode(int responseCode) {
        this.responseCode = responseCode;
    }

    public void setResponseBody(String responseBody) {
        this.responseBody = responseBody;
    }
}


