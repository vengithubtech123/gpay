package com.icici.gpaycommon.pojo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.icici.gpaycommon.dto.PaymentStatusCheckResponse;

import java.util.ArrayList;
import java.util.List;

public class ResponseStatusCheckNEFT implements PaymentStatusCheckResponse {

    @JsonProperty("status")
    private List<NeftStatus> status;
    @JsonProperty("urn")
    private String urn;
    @JsonProperty("uniqueid")
    private String uniqueid;
    @JsonProperty("utrnumber")
    private String utrnumber;
    @JsonProperty("response")
    private String response;
    @JsonIgnore
    private int responseCode;
    @JsonIgnore
    private String responseBody;

    /**
     * No args constructor for use in serialization
     *
     */
    public ResponseStatusCheckNEFT() {
    }

    /**
     *
     * @param urn
     * @param utrnumber
     * @param response
     * @param uniqueid
     * @param status
     */
    public ResponseStatusCheckNEFT(List<NeftStatus> status, String urn, String uniqueid, String utrnumber, String response) {
        super();
        this.status = status;
        this.urn = urn;
        this.uniqueid = uniqueid;
        this.utrnumber = utrnumber;
        this.response = response;
    }

    public List<NeftStatus> getStatus() {
        return status;
    }

    public void setStatus(ArrayList<NeftStatus> status) {
        this.status = status;
    }

    public String getUrn() {
        return urn;
    }

    public void setUrn(String urn) {
        this.urn = urn;
    }

    public String getUniqueid() {
        return uniqueid;
    }

    public void setUniqueid(String uniqueid) {
        this.uniqueid = uniqueid;
    }

    public String getUtrnumber() {
        return utrnumber;
    }

    public void setUtrnumber(String utrnumber) {
        this.utrnumber = utrnumber;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public void setResponseCode(int responseCode) {
        this.responseCode = responseCode;
    }

    public void setResponseBody(String responseBody) {
        this.responseBody = responseBody;
    }

    @Override
    public int getResponseCode() {
        return this.responseCode;
    }

    @Override
    public String getResponseBody() {
        return this.responseBody;
    }
}

