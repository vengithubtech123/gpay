package com.icici.gpaycommon.pojo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.icici.gpaycommon.dto.PaymentResponse;
import com.icici.gpaycommon.dto.PaymentStatusCheckResponse;

public class PaymentResponseErrorNEFT implements PaymentResponse{

    @JsonProperty("MESSAGE")
    private String message;
    @JsonProperty("ERRORCODE")
    private String errorcode;
    @JsonProperty("RESPONSECODE")
    private String responsecode;
    @JsonProperty("STATUS")
    private String status;
    @JsonProperty("RESPONSE")
    private String response;
    @JsonIgnore
    private int responseCode;
    @JsonIgnore
    private String responseBody;

    public PaymentResponseErrorNEFT() {
    }

    public PaymentResponseErrorNEFT(String message, String errorcode, String responsecode, String status, String response) {
        super();
        this.message = message;
        this.errorcode = errorcode;
        this.responsecode = responsecode;
        this.status = status;
        this.response = response;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getErrorcode() {
        return errorcode;
    }

    public void setErrorcode(String errorcode) {
        this.errorcode = errorcode;
    }

    public String getResponsecode() {
        return responsecode;
    }

    public void setResponsecode(String responsecode) {
        this.responsecode = responsecode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public void setResponseCode(int responseCode) {
        this.responseCode = responseCode;
    }

    public void setResponseBody(String responseBody) {
        this.responseBody = responseBody;
    }

    @Override
    public int getResponseCode() {
        return this.responseCode;
    }

    @Override
    public String getResponseBody() {
        return this.responseBody;
    }

}

