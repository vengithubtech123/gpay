package com.icici.gpaycommon.pojo.upi;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author aditya_shekhar on 3/27/2024
 */
public class Recon360Request {
    /*{
        "date": "06/09/2023",
            "recon360": "Y",
            "seq-no": "ICIAJRSkumar587",
            "channel-code": "MICICI",
            "ori-seq-no": "ICIAJRSkumar55",
            "mobile": "7988000014",
            "profile-id": "2996304",
            "device-id": "400438400438400438400438"
    }*/
    @JsonProperty("date")
    private String date;

    @JsonProperty("recon360")
    private String recon360;

    @JsonProperty("seq-no")
    private String seqNo;

    @JsonProperty("channel-code")
    private String channelCode;

    @JsonProperty("ori-seq-no")
    private String oriSeqNo;

    @JsonProperty("mobile")
    private String mobile;

    @JsonProperty("profile-id")
    private String profileId;

    @JsonProperty("device-id")
    private String deviceId;

    public Recon360Request() {
        // TO-DO
    }

    public Recon360Request(String date, String recon360, String seqNo, String channelCode, String oriSeqNo, String mobile, String profileId,
                           String deviceId) {
        this.date = date;
        this.recon360 = recon360;
        this.seqNo = seqNo;
        this.channelCode = channelCode;
        this.oriSeqNo = oriSeqNo;
        this.mobile = mobile;
        this.profileId = profileId;
        this.deviceId = deviceId;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getRecon360() {
        return recon360;
    }

    public void setRecon360(String recon360) {
        this.recon360 = recon360;
    }

    public String getSeqNo() {
        return seqNo;
    }

    public void setSeqNo(String seqNo) {
        this.seqNo = seqNo;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public String getOriSeqNo() {
        return oriSeqNo;
    }

    public void setOriSeqNo(String oriSeqNo) {
        this.oriSeqNo = oriSeqNo;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }
}
