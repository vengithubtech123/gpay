package com.icici.gpaycommon.dto;

/**
 * @author aditya_shekhar on 2/8/2024
 */
public interface PaymentStatusCheckResponse {

    public int getResponseCode();
    public String getResponseBody();
}
