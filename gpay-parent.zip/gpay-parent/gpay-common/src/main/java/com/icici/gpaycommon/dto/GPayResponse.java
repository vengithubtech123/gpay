package com.icici.gpaycommon.dto;

import com.icici.gpaycommon.enums.PAYMENT_STATUS;

/**
 * @author aditya_shekhar on 2/8/2024
 */
public class GPayResponse {

    private String settlementId;
    private String transactionId;
    private String paymentStatus;
    private PaymentReference refPayment;
    private PaymentResponse paymentResponse;

    public GPayResponse() {
        // TO-DO
    }

    public GPayResponse(String settlementId, String transactionId, String paymentStatus, PaymentReference refPayment,
                        PaymentResponse paymentResponse) {
        this.settlementId = settlementId;
        this.transactionId = transactionId;
        this.paymentStatus = paymentStatus;
        this.refPayment = refPayment;
        this.paymentResponse = paymentResponse;
    }

    public GPayResponse(String settlementId, String transactionId, String paymentStatus, PaymentResponse paymentResponse) {
        this.settlementId = settlementId;
        this.transactionId = transactionId;
        this.paymentStatus = paymentStatus;
        this.paymentResponse = paymentResponse;
    }

    public GPayResponse(String settlementId, String transactionId, String paymentStatus) {
        this.settlementId = settlementId;
        this.transactionId = transactionId;
        this.paymentStatus = paymentStatus;
    }

    public String getSettlementId() {
        return settlementId;
    }

    public void setSettlementId(String settlementId) {
        this.settlementId = settlementId;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public PaymentReference getRefPayment() {
        return refPayment;
    }

    public void setRefPayment(PaymentReference refPayment) {
        this.refPayment = refPayment;
    }

    public PaymentResponse getPaymentResponse() {
        return paymentResponse;
    }

    public void setPaymentResponse(PaymentResponse paymentResponse) {
        this.paymentResponse = paymentResponse;
    }
}
