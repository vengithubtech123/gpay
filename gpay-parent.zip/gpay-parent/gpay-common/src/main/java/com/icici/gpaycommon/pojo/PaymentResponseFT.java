package com.icici.gpaycommon.pojo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.icici.gpaycommon.dto.PaymentResponse;

public class PaymentResponseFT implements PaymentResponse {

    @JsonProperty("REQID")
    private String reqid;
    @JsonProperty("STATUS")
    private String status;
    @JsonProperty("UNIQUEID")
    private String uniqueid;
    @JsonProperty("URN")
    private String urn;
    @JsonProperty("UTRNUMBER")
    private String utrnumber;
    @JsonProperty("RESPONSE")
    private String response;

    @JsonIgnore
    private int responseCode;
    @JsonIgnore
    private String responseBody;
    /**
     * No args constructor for use in serialization
     *
     */
    public PaymentResponseFT() {
    }

    /**
     *
     * @param urn
     * @param utrnumber
     * @param response
     * @param uniqueid
     * @param reqid
     * @param status
     */
    public PaymentResponseFT(String reqid, String status, String uniqueid, String urn, String utrnumber, String response) {
        super();
        this.reqid = reqid;
        this.status = status;
        this.uniqueid = uniqueid;
        this.urn = urn;
        this.utrnumber = utrnumber;
        this.response = response;
    }

    public String getReqid() {
        return reqid;
    }

    public void setReqid(String reqid) {
        this.reqid = reqid;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getUniqueid() {
        return uniqueid;
    }

    public void setUniqueid(String uniqueid) {
        this.uniqueid = uniqueid;
    }

    public String getUrn() {
        return urn;
    }

    public void setUrn(String urn) {
        this.urn = urn;
    }

    public String getUtrnumber() {
        return utrnumber;
    }

    public void setUtrnumber(String utrnumber) {
        this.utrnumber = utrnumber;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public void setResponseCode(int responseCode) {
        this.responseCode = responseCode;
    }

    @Override
    public int getResponseCode() {
        return this.responseCode;
    }

    public void setResponseBody(String responseBody) {
        this.responseBody = responseBody;
    }

    @Override
    public String getResponseBody() {
        return this.responseBody;
    }

}