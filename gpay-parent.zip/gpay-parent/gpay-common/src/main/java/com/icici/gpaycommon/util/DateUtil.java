package com.icici.gpaycommon.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * @author aditya_shekhar on 1/20/2024
 */
public class DateUtil {

    public static String getFormattedDate(String dateAsString, String ipFormat, String opFormat) throws ParseException,
            ParseException {
        String formattedDate = "";
        SimpleDateFormat sdf = new SimpleDateFormat(ipFormat);//("dd/MM/yyyy hh:mm:ss a");
        Date date = sdf.parse(dateAsString);
        sdf = new SimpleDateFormat(opFormat);//("dd-MMM-yy hh.mm.ss a");
        formattedDate = sdf.format(date);
        return formattedDate;
    }

    public static Date getFormattedDate(String dateAsString, String ipFormat) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat(ipFormat);//("MMM d, yyyy hh:mm:ss a"); //Mar 2, 2024, 10:31:16 AM
        Date date = sdf.parse(dateAsString);
        return date;
    }

    public static String getFormattedDateString(Date date, String opFormat) {
        String formattedDateString = "";
        DateFormat df = new SimpleDateFormat(opFormat);
        formattedDateString = df.format(date);
        return formattedDateString;
    }

}
