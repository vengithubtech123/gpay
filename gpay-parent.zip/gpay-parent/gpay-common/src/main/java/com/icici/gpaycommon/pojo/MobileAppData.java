package com.icici.gpaycommon.pojo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class MobileAppData {

    @JsonProperty("payee-vpa")
    private String payeeVpa;
    @JsonProperty("payer-ifsc")
    private String payerIfsc;
    @JsonProperty("payer-account")
    private String payerAccount;
    @JsonProperty("original-txn-rrn")
    private Long originalTxnRrn;
    @JsonProperty("npci-resp-code")
    private String npciRespCode;
    @JsonProperty("payer-remarks")
    private String payerRemarks;
    @JsonProperty("original-txn-response-code")
    private String originalTxnResponseCode;
    @JsonProperty("original-txn-message")
    private String originalTxnMessage;
    @JsonProperty("payer-account-type")
    private String payerAccountType;

    /**
     * No args constructor for use in serialization
     *
     */
    public MobileAppData() {
    }
    public MobileAppData(String payeeVpa, String payerIfsc, String payerAccount, Long originalTxnRrn, String npciRespCode, String payerRemarks,
                         String originalTxnResponseCode, String originalTxnMessage, String payerAccountType) {
        super();
        this.payeeVpa = payeeVpa;
        this.payerIfsc = payerIfsc;
        this.payerAccount = payerAccount;
        this.originalTxnRrn = originalTxnRrn;
        this.npciRespCode = npciRespCode;
        this.payerRemarks = payerRemarks;
        this.originalTxnResponseCode = originalTxnResponseCode;
        this.originalTxnMessage = originalTxnMessage;
        this.payerAccountType = payerAccountType;
    }

    public String getPayeeVpa() {
        return payeeVpa;
    }

    public void setPayeeVpa(String payeeVpa) {
        this.payeeVpa = payeeVpa;
    }

    public String getPayerIfsc() {
        return payerIfsc;
    }

    public void setPayerIfsc(String payerIfsc) {
        this.payerIfsc = payerIfsc;
    }

    public String getPayerAccount() {
        return payerAccount;
    }

    public void setPayerAccount(String payerAccount) {
        this.payerAccount = payerAccount;
    }

    public Long getOriginalTxnRrn() {
        return originalTxnRrn;
    }

    public void setOriginalTxnRrn(Long originalTxnRrn) {
        this.originalTxnRrn = originalTxnRrn;
    }

    public String getNpciRespCode() {
        return npciRespCode;
    }

    public void setNpciRespCode(String npciRespCode) {
        this.npciRespCode = npciRespCode;
    }

    public String getPayerRemarks() {
        return payerRemarks;
    }

    public void setPayerRemarks(String payerRemarks) {
        this.payerRemarks = payerRemarks;
    }

    public String getOriginalTxnResponseCode() {
        return originalTxnResponseCode;
    }

    public void setOriginalTxnResponseCode(String originalTxnResponseCode) {
        this.originalTxnResponseCode = originalTxnResponseCode;
    }

    public String getOriginalTxnMessage() {
        return originalTxnMessage;
    }

    public void setOriginalTxnMessage(String originalTxnMessage) {
        this.originalTxnMessage = originalTxnMessage;
    }

    public String getPayerAccountType() {
        return payerAccountType;
    }

    public void setPayerAccountType(String payerAccountType) {
        this.payerAccountType = payerAccountType;
    }

}
