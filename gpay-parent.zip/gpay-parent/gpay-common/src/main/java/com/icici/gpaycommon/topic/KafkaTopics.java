package com.icici.gpaycommon.topic;

/**
 * @author aditya_shekhar on 1/20/2024
 */
public interface KafkaTopics {

    public static final String GPAY_PMT_REQUEST_TOPIC = "GPAY_PAYMENT_REQUEST";
    public static final String GPAY_PMT_VALID_STATUS_TOPIC = "GPAY_PAYMENT_VALID-STATUS"; // retention time: 60 secs
    public static final String GPAY_PMT_VALID_STATUS_LOG_TOPIC = "GPAY_PAYMENT_VALID-STATUS_LOG";
    public static final String GPAY_PMT_PENDING_PARKED_TOPIC = "GPAY_PAYMENT_PENDING_PARKED";
    public static final String GPAY_PMT_PENDING_TRACKER_TOPIC = "GPAY_PAYMENT_PENDING_TRACKER";
    public static final String GPAY_PMT_COMPLETE_TOPIC = "GPAY_PAYMENT_COMPLETE";
    public static final String GPAY_PMT_FAILED_TOPIC = "GPAY_PMT_FAILED_TOPIC";
    public static final String GPAY_PMT_UPI_STATUS_CHECK_TOPIC = "GPAY_PMT_UPI_STATUS-CHECK";
    public static final String GPAY_PMT_UPI_STATUS_CHECK_TEMP_TOPIC = "GPAY_PMT_UPI_STATUS-CHECK_TEMP";
    public static final String GPAY_PMT_UPI_PENDING_TOPIC = "GPAY_PMT_UPI_PENDING";
    public static final String GPAY_PMT_IMPS_STATUS_CHECK_TOPIC = "GPAY_PMT_IMPS_STATUS-CHECK";
    public static final String GPAY_PMT_IMPS_STATUS_CHECK_TEMP_TOPIC = "GPAY_PMT_IMPS_STATUS-CHECK_TEMP";
    public static final String GPAY_PMT_IMPS_PENDING_TOPIC = "GPAY_PMT_IMPS_PENDING";
    public static final String GPAY_PMT_NEFT_STATUS_CHECK_TOPIC = "GPAY_PMT_NEFT_STATUS-CHECK";
    public static final String GPAY_PMT_NEFT_STATUS_CHECK_TEMP_TOPIC = "GPAY_PMT_NEFT_STATUS-CHECK_TEMP";
    public static final String GPAY_PMT_NEFT_PENDING_TOPIC = "GPAY_PMT_NEFT_PENDING";
    public static final String GPAY_PMT_RTGS_STATUS_CHECK_TOPIC = "GPAY_PMT_RTGS_STATUS-CHECK";
    public static final String GPAY_PMT_RTGS_STATUS_CHECK_TEMP_TOPIC = "GPAY_PMT_RTGS_STATUS-CHECK_TEMP";
    public static final String GPAY_PMT_RTGS_PENDING_TOPIC = "GPAY_PMT_RTGS_PENDING";
    public static final String GPAY_PMT_FT_STATUS_CHECK_TOPIC = "GPAY_PMT_FT_STATUS-CHECK";
    public static final String GPAY_PMT_FT_STATUS_CHECK_TEMP_TOPIC = "GPAY_PMT_FT_STATUS-CHECK_TEMP";
    public static final String GPAY_PMT_FT_PENDING_TOPIC = "GPAY_PMT_FT_PENDING";
    public static final String GPAY_PMT_REQUEST_ALT_TOPIC = "GPAY_PAYMENT_REQUEST_ALT";
    public static final String GPAY_PMT_VALID_STATUS_ALT_TOPIC = "GPAY_PAYMENT_VALID-STATUS_ALT";
    public static final String GPAY_PMT_VALID_STATUS_LOG_ALT_TOPIC = "GPAY_PAYMENT_VALID-STATUS_ALT_LOG";
    public static final String GPAY_PMT_PENDING_TRACKER_ALT_TOPIC = "GPAY_PAYMENT_PENDING_TRACKER_ALT";
    public static final String GPAY_PMT_PENDING_PARKED_ALT_TOPIC = "GPAY_PAYMENT_PENDING_PARKED_ALT";
    public static final String GPAY_PMT_COMPLETE_ALT_TOPIC = "GPAY_PAYMENT_COMPLETE_ALT";
    public static final String GPAY_PMT_STATUS_CHECK_TRACKER_TOPIC = "GPAY_PMT_STATUS-CHECK_TRACKER";
    public static final String GPAY_PMT_TRANSACTION_TRACKER_TOPIC = "GPAY_PMT_TRANSACTION_TRACKER";
    public static final String GPAY_PMT_RETRY_DEADLETTER_TOPIC = "GPAY_PMT_RETRY_DEADLETTER";
    public static final String GPAY_PMT_BLOCKED_TOPIC = "GPAY_PMT_BLOCKED";
    public static final String GPAY_PMT_BLOCKED_ALT_TOPIC = "GPAY_PMT_BLOCKED_ALT";
    public static final String GPAY_PMT_UDIR_STATUS_CHECK_TOPIC = "GPAY_PMT_UDIR_STATUS_CHECK";
    public static final String GPAY_PMT_UDIR_PENDING_TOPIC = "GPAY_PMT_UDIR_PENDING";
    public static final String GPAY_PMT_UDIR_STATUS_CHECK_TEMP_TOPIC = "GPAY_PMT_UDIR_STATUS_CHECK_TEMP";


}
