package com.icici.gpaycommon.helper;

import com.icici.gpaycommon.exception.ProcessorException;

import java.util.Collection;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * @author aditya_shekhar on 1/30/2024
 */
public class ThreadpoolManager {

    public List<Future> executePool(int nThreads, Collection tasks) throws ProcessorException {
        ExecutorService executor = Executors.newFixedThreadPool(nThreads);
        List<Future> futureList = null;
        try {
            futureList = executor.invokeAll(tasks);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            //e.printStackTrace();
            throw new ProcessorException(e.getCause().toString());
        }
        return futureList;
    }

}
