package com.icici.gpaycommon.pojo;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.icici.gpaycommon.dto.PaymentRequest;

public class PaymentRequestFT implements PaymentRequest {

    @JsonProperty("tranRefNo")
    private String tranRefNo;
    @JsonProperty("amount")
    private String amount;
    @JsonProperty("senderAcctNo")
    private String senderAcctNo;
    @JsonProperty("beneAccNo")
    private String beneAccNo;
    @JsonProperty("beneName")
    private String beneName;
    @JsonProperty("beneIFSC")
    private String beneIFSC;
    @JsonProperty("narration1")
    private String narration1;
    @JsonProperty("narration2")
    private String narration2;
    @JsonProperty("crpId")
    private String crpId;
    @JsonProperty("crpUsr")
    private String crpUsr;
    @JsonProperty("aggrId")
    private String aggrId;
    @JsonProperty("aggrName")
    private String aggrName;
    @JsonProperty("urn")
    private String urn;
    @JsonProperty("txnType")
    private String txnType;
    @JsonProperty("WORKFLOW_REQD")
    private String workflowReqd;

    /**
     * No args constructor for use in serialization
     *
     */
    public PaymentRequestFT() {
    }

    /**
     *
     * @param amount
     * @param tranRefNo
     * @param workflowReqd
     * @param beneIFSC
     * @param txnType
     * @param narration1
     * @param aggrId
     * @param urn
     * @param senderAcctNo
     * @param narration2
     * @param beneName
     * @param crpId
     * @param crpUsr
     * @param beneAccNo
     * @param aggrName
     */
    public PaymentRequestFT(String tranRefNo, String amount, String senderAcctNo, String beneAccNo, String beneName, String beneIFSC, String narration1, String narration2, String crpId, String crpUsr, String aggrId, String aggrName, String urn, String txnType, String workflowReqd) {
        super();
        this.tranRefNo = tranRefNo;
        this.amount = amount;
        this.senderAcctNo = senderAcctNo;
        this.beneAccNo = beneAccNo;
        this.beneName = beneName;
        this.beneIFSC = beneIFSC;
        this.narration1 = narration1;
        this.narration2 = narration2;
        this.crpId = crpId;
        this.crpUsr = crpUsr;
        this.aggrId = aggrId;
        this.aggrName = aggrName;
        this.urn = urn;
        this.txnType = txnType;
        this.workflowReqd = workflowReqd;
    }

    public String getTranRefNo() {
        return tranRefNo;
    }

    public void setTranRefNo(String tranRefNo) {
        this.tranRefNo = tranRefNo;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getSenderAcctNo() {
        return senderAcctNo;
    }

    public void setSenderAcctNo(String senderAcctNo) {
        this.senderAcctNo = senderAcctNo;
    }

    public String getBeneAccNo() {
        return beneAccNo;
    }

    public void setBeneAccNo(String beneAccNo) {
        this.beneAccNo = beneAccNo;
    }

    public String getBeneName() {
        return beneName;
    }

    public void setBeneName(String beneName) {
        this.beneName = beneName;
    }

    public String getBeneIFSC() {
        return beneIFSC;
    }

    public void setBeneIFSC(String beneIFSC) {
        this.beneIFSC = beneIFSC;
    }

    public String getNarration1() {
        return narration1;
    }

    public void setNarration1(String narration1) {
        this.narration1 = narration1;
    }

    public String getNarration2() {
        return narration2;
    }

    public void setNarration2(String narration2) {
        this.narration2 = narration2;
    }

    public String getCrpId() {
        return crpId;
    }

    public void setCrpId(String crpId) {
        this.crpId = crpId;
    }

    public String getCrpUsr() {
        return crpUsr;
    }

    public void setCrpUsr(String crpUsr) {
        this.crpUsr = crpUsr;
    }

    public String getAggrId() {
        return aggrId;
    }

    public void setAggrId(String aggrId) {
        this.aggrId = aggrId;
    }

    public String getAggrName() {
        return aggrName;
    }

    public void setAggrName(String aggrName) {
        this.aggrName = aggrName;
    }

    public String getUrn() {
        return urn;
    }

    public void setUrn(String urn) {
        this.urn = urn;
    }

    public String getTxnType() {
        return txnType;
    }

    public void setTxnType(String txnType) {
        this.txnType = txnType;
    }

    public String getWorkflowReqd() {
        return workflowReqd;
    }

    public void setWorkflowReqd(String workflowReqd) {
        this.workflowReqd = workflowReqd;
    }

}