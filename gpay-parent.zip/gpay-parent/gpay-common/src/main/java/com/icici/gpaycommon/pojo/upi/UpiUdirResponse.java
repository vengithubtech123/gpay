package com.icici.gpaycommon.pojo.upi;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.icici.gpaycommon.dto.PaymentStatusCheckResponse;
import com.icici.gpaycommon.pojo.MobileAppData;

/**
 * @author aditya_shekhar on 3/27/2024
 */
public class UpiUdirResponse implements PaymentStatusCheckResponse {
    /*{
        "PayeeRevRespCode": "",
            "SeqNo": "ICI45355394ff",
            "BankRRN": "408754477660",
            "UserProfile": "2996304",
            "PayeeRespCode": "",
            "response": "X09",
            "MobileAppData": "",
            "PayerRevRespCode": "",
            "success": false,
            "PayerRespCode": "",
            "message": "TXN.ORGTXNDATE  SHOULD BE WITHIN 90 DAYS",
            "UpiTranlogId": "354477660"
    }*/
    @JsonProperty("PayeeRevRespCode")
    public String payeeRevRespCode;
    @JsonProperty("SeqNo")
    public String seqNo;
    @JsonProperty("BankRRN")
    public String bankRRN;
    @JsonProperty("UserProfile")
    public String userProfile;
    @JsonProperty("PayeeRespCode")
    public String payeeRespCode;
    public String response;
    @JsonProperty("MobileAppData")
    private MobileAppData mobileAppData;
    @JsonProperty("PayerRevRespCode")
    public String payerRevRespCode;
    public boolean success;
    @JsonProperty("PayerRespCode")
    public String payerRespCode;
    public String message;
    @JsonProperty("UpiTranlogId")
    public String upiTranlogId;

    private int responseCode;
    private String responseBody;

    public UpiUdirResponse() {
        //TO-DO
    }

    public UpiUdirResponse(String payeeRevRespCode, String seqNo, String bankRRN, String userProfile, String payeeRespCode, String response,
                           MobileAppData mobileAppData, String payerRevRespCode, boolean success, String payerRespCode, String message,
                           String upiTranlogId) {
        this.payeeRevRespCode = payeeRevRespCode;
        this.seqNo = seqNo;
        this.bankRRN = bankRRN;
        this.userProfile = userProfile;
        this.payeeRespCode = payeeRespCode;
        this.response = response;
        this.mobileAppData = mobileAppData;
        this.payerRevRespCode = payerRevRespCode;
        this.success = success;
        this.payerRespCode = payerRespCode;
        this.message = message;
        this.upiTranlogId = upiTranlogId;
    }

    public String getPayeeRevRespCode() {
        return payeeRevRespCode;
    }

    public void setPayeeRevRespCode(String payeeRevRespCode) {
        this.payeeRevRespCode = payeeRevRespCode;
    }

    public String getSeqNo() {
        return seqNo;
    }

    public void setSeqNo(String seqNo) {
        this.seqNo = seqNo;
    }

    public String getBankRRN() {
        return bankRRN;
    }

    public void setBankRRN(String bankRRN) {
        this.bankRRN = bankRRN;
    }

    public String getUserProfile() {
        return userProfile;
    }

    public void setUserProfile(String userProfile) {
        this.userProfile = userProfile;
    }

    public String getPayeeRespCode() {
        return payeeRespCode;
    }

    public void setPayeeRespCode(String payeeRespCode) {
        this.payeeRespCode = payeeRespCode;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public MobileAppData getMobileAppData() {
        return mobileAppData;
    }

    public void setMobileAppData(MobileAppData mobileAppData) {
        this.mobileAppData = mobileAppData;
    }

    public String getPayerRevRespCode() {
        return payerRevRespCode;
    }

    public void setPayerRevRespCode(String payerRevRespCode) {
        this.payerRevRespCode = payerRevRespCode;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getPayerRespCode() {
        return payerRespCode;
    }

    public void setPayerRespCode(String payerRespCode) {
        this.payerRespCode = payerRespCode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getUpiTranlogId() {
        return upiTranlogId;
    }

    public void setUpiTranlogId(String upiTranlogId) {
        this.upiTranlogId = upiTranlogId;
    }

    @Override
    public int getResponseCode() {
        return responseCode;
    }

    @Override
    public String getResponseBody() {
        return responseBody;
    }

    public void setResponseCode(int responseCode) {
        this.responseCode = responseCode;
    }

    public void setResponseBody(String responseBody) {
        this.responseBody = responseBody;
    }
}