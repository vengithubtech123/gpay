package com.icici.gpaycommon.api;

import com.icici.gpaycommon.helper.PropertyHelper;

import java.util.Properties;

/**
 * @author aditya_shekhar on 2/12/2024
 */
public class UpiSwitch {

    private Properties props;
    {
        //props = PropertyHelper.getInstance().getProperties();
    }
}
