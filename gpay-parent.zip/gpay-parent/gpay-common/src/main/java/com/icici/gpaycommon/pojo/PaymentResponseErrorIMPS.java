package com.icici.gpaycommon.pojo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.icici.gpaycommon.dto.PaymentResponse;

public class PaymentResponseErrorIMPS implements PaymentResponse {

    @JsonProperty("ActCode")
    private String actCode;
    @JsonProperty("Response")
    private String response;

    @JsonIgnore
    private int responseCode;
    @JsonIgnore
    private String responseBody;

    /**
     * No args constructor for use in serialization
     *
     */
    public PaymentResponseErrorIMPS() {
    }

    /**
     *
     * @param actCode
     * @param response
     */
    public PaymentResponseErrorIMPS(String actCode, String response) {
        super();
        this.actCode = actCode;
        this.response = response;
    }

    public String getActCode() {
        return actCode;
    }

    public void setActCode(String actCode) {
        this.actCode = actCode;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    @Override
    public int getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(int responseCode) {
        this.responseCode = responseCode;
    }

    @Override
    public String getResponseBody() {
        return responseBody;
    }

    public void setResponseBody(String responseBody) {
        this.responseBody = responseBody;
    }
}