package com.icici.gpaycommon.api;

/**
 * @author aditya_shekhar on 2/12/2024
 */
public class ImpsSwitch{
}
