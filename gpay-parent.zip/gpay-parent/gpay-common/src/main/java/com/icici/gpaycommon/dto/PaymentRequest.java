package com.icici.gpaycommon.dto;

/**
 * @author aditya_shekhar on 1/20/2024
 */
public interface PaymentRequest {

}
