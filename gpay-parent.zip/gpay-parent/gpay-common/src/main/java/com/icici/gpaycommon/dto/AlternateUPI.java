package com.icici.gpaycommon.dto;

import com.icici.gpaycommon.enums.PAYMENT_STATUS;
import com.icici.gpaycommon.enums.STATUS_CHECK_OPT;
import com.icici.gpaycommon.pojo.upi.Recon360Request;
import com.icici.gpaycommon.pojo.upi.Recon360Response;
import com.icici.gpaycommon.pojo.upi.UpiUdirRequest;
import com.icici.gpaycommon.pojo.upi.UpiUdirResponse;

import java.util.Date;

/**
 * @author aditya_shekhar on 3/28/2024
 */
public class AlternateUPI {
    private STATUS_CHECK_OPT lastAlternate;
    private UpiUdirRequest upiUdirRequest;
    private UpiUdirResponse upiUdirResponse;
    private Recon360Request recon360Request;
    private Recon360Response recon360Response;
    private Date lastRetryDatetime;
    private PAYMENT_STATUS lastStatusCheck;
    private String requestBody;
    private String responseBody;

    public AlternateUPI() {
    }

    public AlternateUPI(STATUS_CHECK_OPT lastAlternate, UpiUdirRequest upiUdirRequest, UpiUdirResponse upiUdirResponse,
                        Recon360Request recon360Request, Recon360Response recon360Response) {
        this.lastAlternate = lastAlternate;
        this.upiUdirRequest = upiUdirRequest;
        this.upiUdirResponse = upiUdirResponse;
        this.recon360Request = recon360Request;
        this.recon360Response = recon360Response;
    }

    public STATUS_CHECK_OPT getLastAlternate() {
        return lastAlternate;
    }

    public void setLastAlternate(STATUS_CHECK_OPT lastAlternate) {
        this.lastAlternate = lastAlternate;
    }

    public UpiUdirRequest getUpiUdirRequest() {
        return upiUdirRequest;
    }

    public void setUpiUdirRequest(UpiUdirRequest upiUdirRequest) {
        this.upiUdirRequest = upiUdirRequest;
    }

    public UpiUdirResponse getUpiUdirResponse() {
        return upiUdirResponse;
    }

    public void setUpiUdirResponse(UpiUdirResponse upiUdirResponse) {
        this.upiUdirResponse = upiUdirResponse;
    }

    public Recon360Request getRecon360Request() {
        return recon360Request;
    }

    public void setRecon360Request(Recon360Request recon360Request) {
        this.recon360Request = recon360Request;
    }

    public Recon360Response getRecon360Response() {
        return recon360Response;
    }

    public void setRecon360Response(Recon360Response recon360Response) {
        this.recon360Response = recon360Response;
    }

    public Date getLastRetryDatetime() {
        return lastRetryDatetime;
    }

    public void setLastRetryDatetime(Date lastRetryDatetime) {
        this.lastRetryDatetime = lastRetryDatetime;
    }

    public PAYMENT_STATUS getLastStatusCheck() {
        return lastStatusCheck;
    }

    public void setLastStatusCheck(PAYMENT_STATUS lastStatusCheck) {
        this.lastStatusCheck = lastStatusCheck;
    }

    public String getRequestBody() {
        return requestBody;
    }

    public void setRequestBody(String requestBody) {
        this.requestBody = requestBody;
    }

    public String getResponseBody() {
        return responseBody;
    }

    public void setResponseBody(String responseBody) {
        this.responseBody = responseBody;
    }
}
