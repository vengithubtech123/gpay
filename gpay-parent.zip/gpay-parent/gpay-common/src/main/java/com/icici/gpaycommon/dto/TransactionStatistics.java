package com.icici.gpaycommon.dto;

import com.icici.gpaycommon.enums.PAYMENT_STATUS;
import com.icici.gpaycommon.enums.PAYMENT_TYPE;

/**
 * @author aditya_shekhar on 2/28/2024
 */
public class TransactionStatistics {

    private String settlementId;
    private String transactionId;
    private String paymentStatus;
    private PAYMENT_TYPE paymentType;
    private String paymentRequest;
    private String paymentResponse;
    private String responseTimestamp;

    public TransactionStatistics() {
        // TO-DO
    }

    public TransactionStatistics(String settlementId, String transactionId, String paymentStatus, PAYMENT_TYPE paymentType,
                                 String paymentRequest, String paymentResponse) {
        this.settlementId = settlementId;
        this.transactionId = transactionId;
        this.paymentStatus = paymentStatus;
        this.paymentType = paymentType;
        this.paymentRequest = paymentRequest;
        this.paymentResponse = paymentResponse;
    }

    public String getSettlementId() {
        return settlementId;
    }

    public void setSettlementId(String settlementId) {
        this.settlementId = settlementId;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public PAYMENT_TYPE getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(PAYMENT_TYPE paymentType) {
        this.paymentType = paymentType;
    }

    public String getPaymentRequest() {
        return paymentRequest;
    }

    public void setPaymentRequest(String paymentRequest) {
        this.paymentRequest = paymentRequest;
    }

    public String getPaymentResponse() {
        return paymentResponse;
    }

    public void setPaymentResponse(String paymentResponse) {
        this.paymentResponse = paymentResponse;
    }

    public String getResponseTimestamp() {
        return responseTimestamp;
    }

    public void setResponseTimestamp(String responseTimestamp) {
        this.responseTimestamp = responseTimestamp;
    }
}
