/*
package com.icici.gpayscheduler.impl;

import com.icici.gpaycommon.exception.ProcessorException;
import com.icici.gpaycommon.helper.PropertyHelper;
import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.DescribeTopicsResult;
import org.apache.kafka.clients.admin.TopicDescription;
import org.apache.kafka.clients.producer.ProducerInterceptor;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.KafkaFuture;
import org.apache.kafka.common.TopicPartitionInfo;

import java.util.Arrays;
import java.util.Collection;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ExecutionException;

public class SchedulerProducerInterceptor<K, V> implements ProducerInterceptor<K, V> {
    private Properties props;
    {
        try {
            props = PropertyHelper.getInstance().getProperties();
        } catch (ProcessorException e) {
            throw new RuntimeException(e);
        }
    }
    private String bootstrapServers = props.getProperty("BOOTSTRAP_SERVERS");

    @Override
    public ProducerRecord<K, V> onSend(ProducerRecord<K, V> record) {
        try (AdminClient adminClient = AdminClient.create(Map.of("bootstrap.servers", bootstrapServers))) {
            Collection<String> topics = Arrays.asList("GPAY_PMT_UPI_STATUS-CHECK", "GPAY_PMT_UPI_PENDING", "GPAY_PMT_TRANSACTION_TRACKER");
            DescribeTopicsResult result = adminClient.describeTopics(topics);
            KafkaFuture<TopicDescription> topicDescriptionFuture = result.all().thenApply(t -> t.get(record.topic()));
            TopicDescription topicDescription = topicDescriptionFuture.get();
            for (TopicPartitionInfo partitionInfo : topicDescription.partitions()) {
                if (partitionInfo.partition() == record.partition()) {
                    System.out.println("Message written to topic: " + record.topic() + ", partition: " + record.partition() +
                            ", leader broker: " + partitionInfo.leader().host());
                    break;
                }
            }
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        return record;
    }

    @Override
    public void onAcknowledgement(RecordMetadata metadata, Exception exception) {
        // No need to implement
    }

    @Override
    public void close() {
        // No resources to close
    }

    @Override
    public void configure(Map<String, ?> configs) {
        this.bootstrapServers = (String) configs.get("bootstrap.servers");
    }
}
*/
