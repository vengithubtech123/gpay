package com.icici.gpayscheduler.impl.ft;

import com.icici.gpaycommon.dto.Payment;
import com.icici.gpaycommon.dto.PaymentRetry;
import com.icici.gpaycommon.enums.PAYMENT_STATUS;
import com.icici.gpaycommon.exception.ProcessorException;
import com.icici.gpaycommon.helper.PropertyHelper;
import com.icici.gpaycommon.serdes.PaymentFtSerdes;
//import com.icici.gpaycommon.serdes.PaymentImpsSerdes;
//import com.icici.gpaycommon.serdes.PaymentSerdes;
import com.icici.gpaycommon.topic.KafkaTopics;
import com.icici.gpayscheduler.impl.BaseProcessor;
import com.icici.gpayscheduler.joiner.PendingPaymentstJoiner;
import com.icici.gpayscheduler.task.TaskMatrix;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.Topology;
import org.apache.kafka.streams.kstream.*;

import java.time.Duration;
import java.util.Date;
import java.util.Properties;

/**
 * @author aditya_shekhar on 2/5/2024
 */
public class FtPendingTaskProcessor extends BaseProcessor{
    private Properties props;
    {
        props = PropertyHelper.getInstance().getProperties();
    }

    private String pmtFtStatusCheckTempTopic = KafkaTopics.GPAY_PMT_FT_STATUS_CHECK_TEMP_TOPIC;
    private String pmtFtStatusCheckTopic = KafkaTopics.GPAY_PMT_FT_STATUS_CHECK_TOPIC;
    private String pmtFtPendingTopic = KafkaTopics.GPAY_PMT_FT_PENDING_TOPIC;
    private String pmtPendingParkedTopic = KafkaTopics.GPAY_PMT_PENDING_PARKED_TOPIC;
    private String appID = props.getProperty("GPAY_FT_PENDING_TASK_APP");
    private StreamsBuilder builder = null;

    public FtPendingTaskProcessor() throws ProcessorException {
        super();
    }

    @Override
    public Topology build(StreamsBuilder builder) {
        builder = new StreamsBuilder();
        //KStream<String, Payment> ftPendingStream = builder.stream(pmtFtPendingTopic, Consumed.with(Serdes.String(), PaymentFtSerdes.serde()));

        KStream<String, Payment> ftPendingStream = builder.stream(pmtFtPendingTopic, Consumed.with(Serdes.String(), PaymentFtSerdes.serde()))
                .groupByKey().windowedBy(TimeWindows.of(Duration.ofSeconds(15)))
                .reduce((value1, value2) -> {
                    System.out.println(value1);
                    return value2;
                })
                .toStream( (windowedKey,value) ->  windowedKey.key());

        ftPendingStream.split().branch((key, value) -> {
                    boolean ftCutoff = false;
                    if(value.getPaymentRetry()!=null) {
                        if (value.getPaymentRetry().getRetryCount()==0) {
                            PaymentRetry retry = value.getPaymentRetry();
                            retry.setLastRetryDatetime(value.getPaymentRespDateTime()!=null ? value.getPaymentRespDateTime() :
                                    value.getPaymentReqDateTime());
                            value.setPaymentRetry(retry);
                        }
                        //Added new parameter for defect fix
                        ftCutoff = TaskMatrix.isFtCutoffApplicable(value.getPaymentRetry(),value.getPaymentRespDateTime());
                    }
                    return ftCutoff;
                }, Branched.withConsumer((ks) -> {
                    ks.mapValues(v -> {
                        PaymentRetry retry = v.getPaymentRetry();
                        if(retry==null) {
                            retry = new PaymentRetry();
                        }
                        retry.setDequeueDatetime(new Date());
                        retry.setRetryCount(retry.getRetryCount() + 1);
                        v.setPaymentRetry(retry);
                        return v;
                    }).to(pmtFtStatusCheckTempTopic, Produced.with(Serdes.String(), PaymentFtSerdes.serde()));
                })).branch((key, value) -> {
                    boolean ftCutoffFail = false;
                    if(value.getPaymentRetry()!=null) {
                        //Added new parameter for defect fix
                        ftCutoffFail = !TaskMatrix.isFtCutoffApplicable(value.getPaymentRetry(),value.getPaymentRespDateTime())
                                && !TaskMatrix.isFtTriesExhausted(value.getPaymentRetry());
                    }
                    return ftCutoffFail;
                }, Branched.withConsumer((ks) -> ks.to(pmtFtPendingTopic, Produced.with(Serdes.String(), PaymentFtSerdes.serde()))))
                .branch((key, value) -> {
                    boolean retriesExhausted = false;
                    if(value.getPaymentRetry()!=null) {
                        retriesExhausted = TaskMatrix.isFtTriesExhausted(value.getPaymentRetry());
                    }
                    return retriesExhausted;
                }, Branched.withConsumer((ks) -> {
                    ks.mapValues(v -> {
                        v.setPaymentStatus(PAYMENT_STATUS.PARKED_PENDING);
                        return v;
                    }).to(pmtPendingParkedTopic, Produced.with(Serdes.String(), PaymentFtSerdes.serde()));
                }));

        ValueJoiner<Payment, Payment, Payment> pendingJoiner = new PendingPaymentstJoiner();
        KTable<String, Payment> ftStatusCheckTempTable = builder.table(pmtFtStatusCheckTempTopic, Consumed.with(Serdes.String(),
                PaymentFtSerdes.serde()));
        KTable<String, Payment> ftStatusCheckTable = builder.table(pmtFtStatusCheckTopic, Consumed.with(Serdes.String(),
                PaymentFtSerdes.serde()));
        KTable<String, Payment> pendingValidTable = ftStatusCheckTempTable.leftJoin(ftStatusCheckTable, pendingJoiner);
        pendingValidTable.toStream().filter((k,v) -> v!=null && v.getUuid()!=null)
                .to(pmtFtStatusCheckTopic, Produced.with(Serdes.String(), PaymentFtSerdes.serde()));

        Topology topology = builder.build();
        return topology;
    }

    @Override
    public void run() {
        Topology topology = build(builder);
        super.streamsConfiguration.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, PaymentFtSerdes.serde().getClass().getName());
        super.streamsConfiguration.put(StreamsConfig.APPLICATION_ID_CONFIG, appID);
        KafkaStreams streams = new KafkaStreams(topology, super.streamsConfiguration);
        streams.start();
    }

    /*public static void main(String[] args) throws ProcessorException {
        System.out.println("FtPendingTaskProcessor starting.....");
        BaseProcessor bp = new FtPendingTaskProcessor();
        bp.run();
        System.out.println("FtPendingTaskProcessor running now.....");
    }*/
}
