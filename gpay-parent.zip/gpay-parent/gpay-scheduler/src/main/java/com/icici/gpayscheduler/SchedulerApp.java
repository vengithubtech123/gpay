package com.icici.gpayscheduler;

import com.icici.gpaycommon.exception.ProcessorException;
import com.icici.gpayscheduler.impl.BaseProcessor;
import com.icici.gpayscheduler.impl.ft.FtPendingTaskProcessor;
import com.icici.gpayscheduler.impl.ft.FtStatusCheckProcessor;
import com.icici.gpayscheduler.impl.imps.ImpsPendingTaskProcessor;
import com.icici.gpayscheduler.impl.imps.ImpsStatusCheckProcessor;
import com.icici.gpayscheduler.impl.neft.NeftPendingTaskProcessor;
import com.icici.gpayscheduler.impl.neft.NeftStatusCheckProcessor;
import com.icici.gpayscheduler.impl.rtgs.RtgsPendingTaskProcessor;
import com.icici.gpayscheduler.impl.rtgs.RtgsStatusCheckProcessor;
import com.icici.gpayscheduler.impl.udir.UdirPendingTaskProcessor;
import com.icici.gpayscheduler.impl.udir.UdirStatusCheckProcessor;
import com.icici.gpayscheduler.impl.upi.UpiPendingTaskProcessor;
import com.icici.gpayscheduler.impl.upi.UpiStatusCheckProcessor;

import java.time.Instant;
import java.util.Date;
import java.util.Optional;
import java.util.Properties;
import java.util.concurrent.Executor;

/**
 * @author aditya_shekhar on 2/2/2024
 */
public class SchedulerApp {

    public static void main(String[] args) throws ProcessorException {

        System.out.println("UpiPendingTaskProcessor starting.....");
        BaseProcessor bp1 = new UpiPendingTaskProcessor();
        bp1.run();
        System.out.println("UpiStatusCheckProcessor running now.....");

        System.out.println("UpiStatusCheckProcessor starting.....");
        BaseProcessor bp2 = new UpiStatusCheckProcessor();
        bp2.run();
        System.out.println("UpiStatusCheckProcessor running now.....");

        System.out.println("ImpsPendingTaskProcessor starting.....");
        BaseProcessor bp3 = new ImpsPendingTaskProcessor();
        bp3.run();
        System.out.println("ImpsPendingTaskProcessor running now.....");

        System.out.println("ImpsStatusCheckProcessor starting.....");
        BaseProcessor bp4 = new ImpsStatusCheckProcessor();
        bp4.run();
        System.out.println("ImpsStatusCheckProcessor running now.....");

        System.out.println("NeftPendingTaskProcessor starting.....");
        BaseProcessor bp5 = new NeftPendingTaskProcessor();
        bp5.run();
        System.out.println("NeftPendingTaskProcessor running now.....");

        System.out.println("NeftStatusCheckProcessor starting.....");
        BaseProcessor bp6 = new NeftStatusCheckProcessor();
        bp6.run();
        System.out.println("NeftStatusCheckProcessor running now.....");

        System.out.println("RtgsPendingTaskProcessor starting.....");
        BaseProcessor bp7 = new RtgsPendingTaskProcessor();
        bp7.run();
        System.out.println("RtgsPendingTaskProcessor running now.....");

        System.out.println("RtgsStatusCheckProcessor starting.....");
        BaseProcessor bp8 = new RtgsStatusCheckProcessor();
        bp8.run();
        System.out.println("RtgsStatusCheckProcessor running now.....");

        System.out.println("FtPendingTaskProcessor starting.....");
        BaseProcessor bp9 = new FtPendingTaskProcessor();
        bp9.run();
        System.out.println("FtPendingTaskProcessor running now.....");

        System.out.println("FtStatusCheckProcessor starting.....");
        BaseProcessor bp10 = new FtStatusCheckProcessor();
        bp10.run();
        System.out.println("FtStatusCheckProcessor running now.....");

        System.out.println("UdirPendingTaskProcessor starting.....");
        BaseProcessor bp11 = new UdirPendingTaskProcessor();
        bp11.run();
        System.out.println("UdirStatusCheckProcessor running now.....");

        System.out.println("UdirStatusCheckProcessor starting.....");
        BaseProcessor bp12 = new UdirStatusCheckProcessor();
        bp12.run();
        System.out.println("UdirStatusCheckProcessor running now.....");
    }

}
