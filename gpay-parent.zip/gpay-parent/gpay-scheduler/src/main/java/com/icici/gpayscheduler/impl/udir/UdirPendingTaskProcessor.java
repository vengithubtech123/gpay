package com.icici.gpayscheduler.impl.udir;

import com.icici.gpaycommon.dto.Payment;
import com.icici.gpaycommon.dto.PaymentRetry;
import com.icici.gpaycommon.enums.PAYMENT_STATUS;
import com.icici.gpaycommon.exception.ProcessorException;
import com.icici.gpaycommon.helper.PropertyHelper;
import com.icici.gpaycommon.serdes.PaymentSerdes;
import com.icici.gpaycommon.topic.KafkaTopics;
import com.icici.gpayscheduler.impl.BaseProcessor;
import com.icici.gpayscheduler.joiner.PendingPaymentstJoiner;
import com.icici.gpayscheduler.task.TaskMatrix;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.Topology;
import org.apache.kafka.streams.kstream.*;

import java.time.Duration;
import java.util.Date;
import java.util.Properties;

/**
 * @author aditya_shekhar on 3/27/2024
 */
public class UdirPendingTaskProcessor extends BaseProcessor {
    private Properties props;
    {
        props = PropertyHelper.getInstance().getProperties();
    }

    private String pmtUpiStatusCheckTempTopic = KafkaTopics.GPAY_PMT_UDIR_STATUS_CHECK_TEMP_TOPIC;
    private String pmtUpiStatusCheckTopic = KafkaTopics.GPAY_PMT_UDIR_STATUS_CHECK_TOPIC;
    private String pmtUpiPendingTopic = KafkaTopics.GPAY_PMT_UDIR_PENDING_TOPIC;
    private String pmtPendingParkedTopic = KafkaTopics.GPAY_PMT_PENDING_PARKED_TOPIC;
    private String appID = props.getProperty("GPAY_UDIR_PENDING_TASK_APP");
    private StreamsBuilder builder = null;

    public UdirPendingTaskProcessor() throws ProcessorException {
        super();
    }

    @Override
    public Topology build(StreamsBuilder builder) {
        builder = new StreamsBuilder();
        //KStream<String, Payment> upiPendingStream = builder.stream(pmtUpiPendingTopic, Consumed.with(Serdes.String(), PaymentSerdes.serde()));

        KStream<String, Payment> upiPendingStream = builder.stream(pmtUpiPendingTopic, Consumed.with(Serdes.String(), PaymentSerdes.serde()))
                .groupByKey().windowedBy(TimeWindows.of(Duration.ofSeconds(60)))
                .reduce((value1, value2) -> {
                    System.out.println(value1);
                    return value2;
                })
                .toStream( (windowedKey,value) ->  windowedKey.key());

        upiPendingStream.peek((k,v) -> System.out.println("udirPendingStream :- " + v.getSettlementId() + "::" + v.getTransactionId()));

        upiPendingStream.split().branch((key, value) -> {
                    boolean upiCutoff = false;
                    if(value.getPaymentRetry()!=null) {
                        if (value.getPaymentRetry().getRetryCountAlternate()==0) {
                            PaymentRetry retry = value.getPaymentRetry();
                            retry.setLastRetryDatetime(value.getPaymentRespDateTime()!=null ? value.getPaymentRespDateTime() :
                                    value.getPaymentReqDateTime());
                            value.setPaymentRetry(retry);
                        }
                        System.out.println("udirPendingStream upiCutoff:- " + upiCutoff);
                        upiCutoff = TaskMatrix.isUdirCutoffApplicable(value.getPaymentRetry());
                    }
                    return upiCutoff;
                }, Branched.withConsumer((ks) -> {
                    ks.mapValues(v -> {
                        PaymentRetry retry = v.getPaymentRetry();
                        if(retry==null) {
                            retry = new PaymentRetry();
                        }
                        retry.setDequeueDatetime(new Date());
                        retry.setRetryCountAlternate(retry.getRetryCountAlternate() + 1);
                        v.setPaymentRetry(retry);
                        System.out.println("udirPendingStream Branched.withConsumer:- " + v.getSettlementId() + "::" + v.getTransactionId());
                        return v;
                    }).to(pmtUpiStatusCheckTempTopic, Produced.with(Serdes.String(), PaymentSerdes.serde()));
                })).branch((key, value) -> {
                    boolean upiCutoffFail = false;
                    int retryC = value.getPaymentRetry().getRetryCountAlternate();
                    if(value.getPaymentRetry()!=null) {
                        upiCutoffFail = !TaskMatrix.isUdirCutoffApplicable(value.getPaymentRetry())
                                && !TaskMatrix.isUdirTriesExhausted(value.getPaymentRetry());
                    }
                    System.out.println("udirPendingStream upiCutoffFail" + upiCutoffFail);
                    return upiCutoffFail;
                }, Branched.withConsumer((ks) -> ks.to(pmtUpiPendingTopic, Produced.with(Serdes.String(), PaymentSerdes.serde()))))
                .branch((key, value) -> {
                    boolean retriesExhausted = false;
                    if(value.getPaymentRetry()!=null) {
                        retriesExhausted = TaskMatrix.isUdirTriesExhausted(value.getPaymentRetry());
                    }
                    System.out.println("udirPendingStream retriesExhausted" + retriesExhausted);
                    return retriesExhausted;
                }, Branched.withConsumer((ks) -> {
                    ks.mapValues(v -> {
                        v.setPaymentStatus(PAYMENT_STATUS.PARKED_PENDING);
                        System.out.println("udirPendingStream Branched.withConsumer((ks)" + v.getTransactionId());
                        return v;
                    }).to(pmtPendingParkedTopic, Produced.with(Serdes.String(), PaymentSerdes.serde()));
                }));

        ValueJoiner<Payment, Payment, Payment> pendingJoiner = new PendingPaymentstJoiner();
        KTable<String, Payment> upiStatusCheckTempTable = builder.table(pmtUpiStatusCheckTempTopic, Consumed.with(Serdes.String(),
                PaymentSerdes.serde()));
        KTable<String, Payment> upiStatusCheckTable = builder.table(pmtUpiStatusCheckTopic, Consumed.with(Serdes.String(),
                PaymentSerdes.serde()));
        KTable<String, Payment> pendingValidTable = upiStatusCheckTempTable.leftJoin(upiStatusCheckTable, pendingJoiner);
        pendingValidTable.toStream().filter((k,v) -> v!=null && v.getUuid()!=null)
                .to(pmtUpiStatusCheckTopic, Produced.with(Serdes.String(), PaymentSerdes.serde()));

        Topology topology = builder.build();
        return topology;
    }

    @Override
    public void run() {
        Topology topology = build(builder);
        super.streamsConfiguration.put(StreamsConfig.APPLICATION_ID_CONFIG, appID);
        KafkaStreams streams = new KafkaStreams(topology, super.streamsConfiguration);
        streams.start();
    }

    /*public static void main(String[] args) throws ProcessorException {
        System.out.println("UdirPendingTaskProcessor starting.....");
        BaseProcessor bp = new UdirPendingTaskProcessor();
        bp.run();
        System.out.println("UdirPendingTaskProcessor running now.....");
    }*/
}
