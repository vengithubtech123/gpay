package com.icici.gpayscheduler.impl.neft;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.icici.gpaycommon.api.PaymentSwitch;
import com.icici.gpaycommon.dto.Payment;
import com.icici.gpaycommon.dto.PaymentRetry;
import com.icici.gpaycommon.enums.PAYMENT_STATUS;
import com.icici.gpaycommon.exception.ProcessorException;
import com.icici.gpaycommon.helper.PropertyHelper;
import com.icici.gpaycommon.pojo.*;
import com.icici.gpaycommon.serdes.PaymentNeftSerdes;
import com.icici.gpaycommon.topic.KafkaTopics;
import com.icici.gpaycommon.util.DateUtil;
import com.icici.gpayscheduler.impl.BaseProcessor;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.Topology;
import org.apache.kafka.streams.kstream.Branched;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.Produced;

import java.util.Date;
import java.util.Properties;

/**
 * @author aditya_shekhar on 2/6/2024
 */
public class NeftStatusCheckProcessor extends BaseProcessor{
    private Properties props;
    {
        props = PropertyHelper.getInstance().getProperties();
    }
    private String pmtNeftStatusCheckTopic = KafkaTopics.GPAY_PMT_NEFT_STATUS_CHECK_TOPIC;
    private String pmtNeftPendingTopic = KafkaTopics.GPAY_PMT_NEFT_PENDING_TOPIC;
    private String pmtStatusCheckTrackerTopic = KafkaTopics.GPAY_PMT_STATUS_CHECK_TRACKER_TOPIC;
    private String pmtCompleteTopic = KafkaTopics.GPAY_PMT_COMPLETE_TOPIC;
    private String pmtRetryDeadletter = KafkaTopics.GPAY_PMT_RETRY_DEADLETTER_TOPIC;
    private int threadCount = Integer.parseInt(props.getProperty("NEFT_STATUS_CHECK_THREAD_COUNT"));
    private String appID = props.getProperty("GPAY_NEFT_STATUS_CHECK_APP");
    private StreamsBuilder builder = null;
    private PaymentSwitch paymentSwitch = new PaymentSwitch();

    public NeftStatusCheckProcessor() throws ProcessorException {
        super();
        super.streamsConfiguration.put(StreamsConfig.NUM_STREAM_THREADS_CONFIG, threadCount);
    }

    @Override
    public Topology build(StreamsBuilder builder) {
        builder = new StreamsBuilder();
        ObjectMapper om = new ObjectMapper();
        om.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, false);
        om.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        om.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        KStream<String, Payment> neftRetryStream = builder.stream(pmtNeftStatusCheckTopic, Consumed.with(Serdes.String(),
                PaymentNeftSerdes.serde()));
        KStream<String, Payment> processedNeftTasks = neftRetryStream.filter((k, v) ->
                v!=null && v.getTransactionId()!=null && v.getSettlementId()!=null && v.getPaymentResponse()!=null).mapValues( v -> {
            Payment paymentFinal = null;
            // Call Status Check API
            try {
                PaymentRequestNEFT neftPaymentReq = (PaymentRequestNEFT) v.getPaymentRequest();
                PaymentResponseNEFT neftPaymentResp = (PaymentResponseNEFT) v.getPaymentResponse();
                RequestStatusCheckNEFT statusCheckReqNeft = new RequestStatusCheckNEFT();
                statusCheckReqNeft.setAggrid(neftPaymentReq.getAggrId());
                statusCheckReqNeft.setUniqueid(neftPaymentReq.getTranRefNo());
                statusCheckReqNeft.setDate(DateUtil.getFormattedDateString(new Date(), "yyyyMMdd"));
                PaymentRetry paymentRetry = v.getPaymentRetry();
                paymentRetry.setPaymentStatusCheckRequest(statusCheckReqNeft);
                try {
                    paymentRetry.setStatusCheckReqString(om.writeValueAsString(statusCheckReqNeft));
                } catch (JsonProcessingException e) {
                    e.printStackTrace();
                }
                v.setPaymentRetry(paymentRetry);
                paymentFinal = paymentSwitch.checkPaymentStatus(v);
            } catch (ProcessorException e) {
                // Add logging for Switch errors
                e.printStackTrace();
                PaymentRetry paymentRetry = v.getPaymentRetry();
                paymentRetry.setPaymentStatusCheckResponse(null);
                paymentRetry.setLastStatusCheck(PAYMENT_STATUS.PENDING);
                v.setPaymentRetry(paymentRetry);
                paymentFinal = v;
            }
            return paymentFinal;
        });

        processedNeftTasks.filter( (k,v) -> v!=null).split().branch((key, value) -> {
                    return (value.getPaymentRetry().getLastStatusCheck()==PAYMENT_STATUS.SUCCESS ||
                            value.getPaymentRetry().getLastStatusCheck()==PAYMENT_STATUS.FAILED);
                }, Branched.withConsumer((ks) -> ks.mapValues(val -> {
                            val.setPaymentStatus(val.getPaymentRetry().getLastStatusCheck());
                            return val;
                        }).to(pmtCompleteTopic, Produced.with(Serdes.String(), PaymentNeftSerdes.serde()))
                )).branch((key, value) -> {
                    return value.getPaymentRetry().getLastStatusCheck()==PAYMENT_STATUS.PENDING;
                }, Branched.withConsumer((ks) -> {
                    KStream<String, Payment> pmtPendingStream = ks.mapValues(v -> {
                        PaymentRetry retry = v.getPaymentRetry();
                        if(retry==null) {
                            retry = new PaymentRetry();
                        }
                        retry.setEnqueueDatetime(new Date());
                        v.setPaymentRetry(retry);
                        return v;
                    });
                    pmtPendingStream.to(pmtNeftPendingTopic, Produced.with(Serdes.String(), PaymentNeftSerdes.serde()));
                    pmtPendingStream.to(pmtStatusCheckTrackerTopic, Produced.with(Serdes.String(), PaymentNeftSerdes.serde()));
                }))
                .branch((key, value) -> {
                    return (value.getPaymentRetry().getLastStatusCheck()==null);
                }, Branched.withConsumer((ks) -> ks.to(pmtRetryDeadletter, Produced.with(Serdes.String(), PaymentNeftSerdes.serde()))
                ));

        Topology topology = builder.build();
        return topology;
    }

    @Override
    public void run() {
        Topology topology = build(builder);
        streamsConfiguration.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, PaymentNeftSerdes.serde().getClass().getName());
        super.streamsConfiguration.put(StreamsConfig.APPLICATION_ID_CONFIG, appID);
        KafkaStreams streams = new KafkaStreams(topology, super.streamsConfiguration);
        streams.start();
    }

    /*public static void main(String[] args) throws ProcessorException {
        System.out.println("NeftStatusCheckProcessor starting.....");
        BaseProcessor bp = new NeftStatusCheckProcessor();
        bp.run();
        System.out.println("NeftStatusCheckProcessor running now.....");
    }*/
}
