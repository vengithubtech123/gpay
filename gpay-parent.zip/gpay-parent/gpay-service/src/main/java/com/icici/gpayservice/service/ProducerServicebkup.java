/*
package com.icici.gpayservice.service;

import com.icici.gpaycommon.dto.Payment;
import com.icici.gpaycommon.dto.PaymentRetry;
import com.icici.gpaycommon.enums.PAYMENT_TYPE;
import com.icici.gpaycommon.exception.ProcessorException;
import com.icici.gpaycommon.topic.KafkaTopics;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFuture;

import java.util.Properties;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicReference;

*/
/**
 * @author aditya_shekhar on 3/1/2024
 *//*

@Service
public class ProducerService {

    @Autowired
    private KafkaTemplate<String, Payment> kafkaTemplate;

    @Autowired
    private Properties brokerProps;

    public void sendPaymentRequest(Payment paymentRequest) {
        ListenableFuture<SendResult<String, Payment>> future = kafkaTemplate.send(KafkaTopics.GPAY_PMT_REQUEST_TOPIC,
                paymentRequest.getSettlementId(), paymentRequest);
        future.completable().whenComplete((result, ex) -> {
            if (ex == null) {
                System.out.println("Sent message=[" + paymentRequest.getSettlementId() + "] with offset=["
                        + result.getRecordMetadata().offset() + "]");
            } else {
                System.out.println("Unable to send message=[" + paymentRequest.getSettlementId() + "] due to : " + ex.getMessage());
            }
        });
    }

    public void sendPaymentSuccess(Payment paymentRequest) {
        ListenableFuture<SendResult<String, Payment>> future = kafkaTemplate.send(KafkaTopics.GPAY_PMT_COMPLETE_TOPIC,
                paymentRequest.getSettlementId(), paymentRequest);
        future.completable().whenComplete((result, ex) -> {
            if (ex == null) {
                System.out.println("sendPaymentSuccess=[" + paymentRequest.getSettlementId() + "] with offset=["
                        + result.getRecordMetadata().offset() + "]");
            } else {
                System.out.println("Unable to send message=[" + paymentRequest.getSettlementId() + "] due to : " + ex.getMessage());
            }
        });
    }

    public void sendPaymentFailure(Payment paymentFailure) {
        */
/*ListenableFuture<SendResult<String, Payment>> future = kafkaTemplate.send(KafkaTopics.GPAY_PMT_FAILED_TOPIC,
                paymentFailure.getSettlementId(), paymentFailure);*//*

        ListenableFuture<SendResult<String, Payment>> future = kafkaTemplate.send(KafkaTopics.GPAY_PMT_COMPLETE_TOPIC,
                paymentFailure.getSettlementId(), paymentFailure);
        future.completable().whenComplete((result, ex) -> {
            if (ex == null) {
                System.out.println("sendPaymentFailure=[" + paymentFailure.getSettlementId() + "] with offset=["
                        + result.getRecordMetadata().offset() + "]");
            } else {
                System.out.println("Unable to send message::sendPaymentFailure=[" + paymentFailure.getSettlementId() + "] due to : "
                        + ex.getMessage());
            }
        });
    }

    public void sendPaymentBlocked(Payment paymentBlocked) {
        ListenableFuture<SendResult<String, Payment>> future = kafkaTemplate.send(KafkaTopics.GPAY_PMT_BLOCKED_TOPIC,
                paymentBlocked.getSettlementId(), paymentBlocked);
        future.completable().whenComplete((result, ex) -> {
            if (ex == null) {
                System.out.println("sendPaymentBlocked=[" + paymentBlocked.getSettlementId() + "] with offset=["
                        + result.getRecordMetadata().offset() + "]");
            } else {
                System.out.println("Unable to send message::sendPaymentBlocked=[" + paymentBlocked.getSettlementId() + "] due to : "
                        + ex.getMessage());
            }
        });
    }

    public void sendPaymentDeadletter(Payment paymentWIP) {
        ListenableFuture<SendResult<String, Payment>> future = kafkaTemplate.send(KafkaTopics.GPAY_PMT_RETRY_DEADLETTER_TOPIC,
                paymentWIP.getSettlementId(), paymentWIP);
        future.completable().whenComplete((result, ex) -> {
            if (ex == null) {
                System.out.println("sendPaymentDeadletter=[" + paymentWIP.getSettlementId() + "] with offset=["
                        + result.getRecordMetadata().offset() + "]");
            } else {
                System.out.println("Unable to send message::sendPaymentDeadletter=[" + paymentWIP.getSettlementId() + "] due to : "
                        + ex.getMessage());
            }
        });
    }

    public CompletableFuture<RecordMetadata> sendToPendingTracker(Payment paymentPending) throws ProcessorException {
        Payment paymentResponse = paymentPending;
        PaymentRetry retry = new PaymentRetry();
        paymentResponse.setPaymentRetry(retry);
        //LOG.info("Looking up Settlement ID: {}", paymentRequest);
        Producer<String, Payment> producer = null;
        producer = new KafkaProducer<>(brokerProps);
        try {
            producer = new KafkaProducer<String, Payment>(brokerProps);
        } catch (Exception e) {
            e.printStackTrace();
        }
        ProducerRecord<String, Payment> record = new ProducerRecord<String, Payment>(KafkaTopics.GPAY_PMT_PENDING_TRACKER_TOPIC,
                paymentResponse.getSettlementId(), paymentResponse);
        RecordMetadata metadata = null;
        if (producer != null) {
            try {
                Future<RecordMetadata> future = producer.send(record);
                metadata = future.get();
                System.out.println("sendToPendingTracker:Tracker=[" + paymentResponse.getUuid() + " :: " +
                        paymentResponse.getSettlementId() + "] with offset=["
                        + metadata.offset() + "], at partition=[" + metadata.partition() + "]");
            } catch (Exception e) {
                System.err.println(e.getMessage());
                e.printStackTrace();
                throw new ProcessorException(e.getMessage());
            }
        }
        sendForPending(paymentResponse);
        //Thread.sleep(4000L);
        return CompletableFuture.completedFuture(metadata);
    }
    public void sendPaymentPending1(Payment paymentPending) throws ProcessorException {
        Payment paymentResponse = paymentPending;
        PaymentRetry retry = new PaymentRetry();
        paymentResponse.setPaymentRetry(retry);
        ListenableFuture<SendResult<String, Payment>> futureTracker = kafkaTemplate.send(KafkaTopics.GPAY_PMT_PENDING_TRACKER_TOPIC,
                paymentResponse.getSettlementId(), paymentResponse);
        AtomicReference<String> exception = new AtomicReference<>("");
                futureTracker.completable().whenComplete((result, ex) -> {
            if (ex == null) {
                System.out.println("sendPaymentPending:Tracker=[" + paymentResponse.getSettlementId() + "] with offset=["
                        + result.getRecordMetadata().offset() + "]");
                sendForPending(paymentResponse);
            } else {
                exception.set("Unable to send message::sendPaymentPending:Tracker=[" + paymentResponse.getSettlementId() + "] due to : "
                        + ex.getMessage());
                System.out.println(exception.get());
            }
        });
        if(exception.get().length()>0) {
            throw new ProcessorException(exception.get());
        }
    }

    private void sendForPending(Payment paymentResponse) {
        PAYMENT_TYPE paymentType = paymentResponse.getPaymentType();
        ListenableFuture<SendResult<String, Payment>> futurePending = null;
        switch(paymentType) {
            case IMPS:
                futurePending = kafkaTemplate.send(KafkaTopics.GPAY_PMT_IMPS_PENDING_TOPIC, paymentResponse.getSettlementId(), paymentResponse);
                break;
            case UPI:
                futurePending = kafkaTemplate.send(KafkaTopics.GPAY_PMT_UPI_PENDING_TOPIC, paymentResponse.getSettlementId(), paymentResponse);
                break;
            case NEFT:
                futurePending = kafkaTemplate.send(KafkaTopics.GPAY_PMT_NEFT_PENDING_TOPIC, paymentResponse.getSettlementId(), paymentResponse);
                break;
            case RTGS:
                futurePending = kafkaTemplate.send(KafkaTopics.GPAY_PMT_RTGS_PENDING_TOPIC, paymentResponse.getSettlementId(), paymentResponse);
                break;
            case FT:
                futurePending = kafkaTemplate.send(KafkaTopics.GPAY_PMT_FT_PENDING_TOPIC, paymentResponse.getSettlementId(), paymentResponse);
                break;
        }
        futurePending.completable().whenComplete((result, ex) -> {
            if (ex == null) {
                System.out.println("sendForPending=[" + paymentResponse.getSettlementId() + "] with offset=["
                        + result.getRecordMetadata().offset() + "]");
            } else {
                System.out.println("Unable to send message::sendForPending=[" + paymentResponse.getSettlementId() + "] due to : "
                        + ex.getMessage());
            }
        });
    }
}
*/
