package com.icici.gpayservice.service;

import com.icici.gpaycommon.exception.ProcessorException;
import io.confluent.ksql.api.client.BatchedQueryResult;
import io.confluent.ksql.api.client.Client;
import io.confluent.ksql.api.client.ClientOptions;
import io.confluent.ksql.api.client.Row;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;


/**
 * @author aditya_shekhar on 1/20/2024
 */
@Service
public class DatabaseConnectionManager {

    @Autowired
    private ClientOptions ksqlClientOptions;
    @Value("${KSQLDB_SERVER_HOST}")
    private String ksqlHost;
    @Value("${KSQLDB_SERVER_PORT}")
    private int ksqlPort;
    private DatabaseConnectionManager instance;
    private ClientOptions options;

    private DatabaseConnectionManager() {
    }

    public DatabaseConnectionManager getInstance() {
        if (instance == null) {
            instance = new DatabaseConnectionManager();
            instance.options = ksqlClientOptions;
        }
        return instance;
    }

    public List<Row> getData(String sql) throws ProcessorException {
        Client client = Client.create(options);
        try {
            System.out.println(sql);
            BatchedQueryResult result = client.executeQuery(sql);
            List<Row> rows = result.get(30, TimeUnit.SECONDS);
            return rows;
        } catch (InterruptedException|ExecutionException|TimeoutException e) {
            e.printStackTrace();
            throw new ProcessorException(e.getMessage());
        } finally {
            client.close();
        }
    }

}
