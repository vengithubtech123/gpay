CREATE SOURCE TABLE IF NOT EXISTS
GPAY_PAYMENT_VALID_STATUS_VIEW (
uuid STRING PRIMARY KEY,
settlementId STRING,
transactionId STRING,
paymentType STRING,
paymentStatus STRING,
paymentReference STRUCT<settlementId VARCHAR, transactionId VARCHAR, refPaymentStatus VARCHAR>)
WITH (kafka_topic='GPAY_PAYMENT_VALID-STATUS_LOG', partitions=3, value_format='JSON');

CREATE SOURCE TABLE IF NOT EXISTS
GPAY_PAYMENT_VALID_STATUS_ALT_VIEW (
uuid STRING PRIMARY KEY,
settlementId STRING,
transactionId STRING,
paymentType STRING,
paymentStatus STRING,
paymentReference STRUCT<settlementId VARCHAR, transactionId VARCHAR, refPaymentStatus VARCHAR>)
WITH (kafka_topic='GPAY_PAYMENT_VALID-STATUS_ALT_LOG', partitions=3, value_format='JSON');

CREATE TABLE IF NOT EXISTS
 gpay_payment_status_enriched AS
  SELECT status.uuid AS uuid, status.settlementId AS settlementId,
         status.transactionId AS transactionId, status.paymentType AS paymentType,
         status.paymentStatus AS paymentStatusSettlement, status_alt.paymentStatus AS paymentStatusTransaction,
         status.paymentReference->settlementId AS settlementIdStatus, status.paymentReference->transactionId AS transactionIdStatus, status.paymentReference->refPaymentStatus AS refPaymentStatus,
	   status_alt.paymentReference->settlementId AS settlementIdStatusAlt, status_alt.paymentReference->transactionId AS transactionIdStatusAlt, status_alt.paymentReference->refPaymentStatus AS refPaymentStatusAlt
  FROM GPAY_PAYMENT_VALID_STATUS_VIEW status
  JOIN GPAY_PAYMENT_VALID_STATUS_ALT_VIEW status_alt ON status.uuid = status_alt.uuid
  WHERE status.settlementId = status_alt.settlementId AND status.transactionId = status_alt.transactionId;


CREATE TABLE IF NOT EXISTS
 gpay_payment_status_enriched AS
  SELECT status_alt.uuid AS uuid, status_alt.settlementId AS settlementId,
         status_alt.transactionId AS transactionId, status_alt.paymentType AS paymentType,
         status.paymentStatus AS paymentStatusSettlement, status_alt.paymentStatus AS paymentStatusTransaction,
         status.paymentReference->settlementId AS settlementIdStatus, status.paymentReference->transactionId AS transactionIdStatus, status.paymentReference->refPaymentStatus AS refPaymentStatus,
	   status_alt.paymentReference->settlementId AS settlementIdStatusAlt, status_alt.paymentReference->transactionId AS transactionIdStatusAlt, status_alt.paymentReference->refPaymentStatus AS refPaymentStatusAlt
  FROM GPAY_PAYMENT_VALID_STATUS_ALT_VIEW status_alt
  LEFT JOIN GPAY_PAYMENT_VALID_STATUS_VIEW status ON status.uuid = status_alt.uuid;


  CREATE TABLE IF NOT EXISTS
   gpay_payment_status_enriched AS
    SELECT ROWKEY AS id, status_alt.uuid AS uuid, status_alt.settlementId AS settlementId,
           status_alt.transactionId AS transactionId, status_alt.paymentType AS paymentType,
           status.paymentStatus AS paymentStatusSettlement, status_alt.paymentStatus AS paymentStatusTransaction,
           status.paymentReference->settlementId AS settlementIdStatus, status.paymentReference->transactionId AS transactionIdStatus, status.paymentReference->refPaymentStatus AS refPaymentStatus,
  	   status_alt.paymentReference->settlementId AS settlementIdStatusAlt, status_alt.paymentReference->transactionId AS transactionIdStatusAlt, status_alt.paymentReference->refPaymentStatus AS refPaymentStatusAlt
    FROM GPAY_PAYMENT_VALID_STATUS_ALT_VIEW status_alt
    FULL OUTER JOIN GPAY_PAYMENT_VALID_STATUS_VIEW status ON status.uuid = status_alt.uuid;


CREATE SOURCE TABLE IF NOT EXISTS gpay_payment_transaction_tracker (
uuid STRING, settlementId STRING, transactionId STRING PRIMARY KEY, paymentType STRING, paymentStatus STRING, paymentReqString STRING,
paymentResponse STRUCT<responseBody VARCHAR>, paymentRespDateTime VARCHAR,
paymentRetry STRUCT<retryCount INT, lastStatusCheck VARCHAR, paymentStatusCheckResponse STRUCT<responseBody VARCHAR>,
paymentStatusCheckRequest VARCHAR, lastRetryDatetime VARCHAR, statusCheckReqString VARCHAR>)
WITH (kafka_topic='GPAY_PMT_TRANSACTION_TRACKER', partitions=3, value_format='JSON');

CREATE TABLE payment_complete AS
  SELECT
    settlement_id,
    TIMESTAMPTOSTRING(WINDOWSTART, 'yyyy-MM-dd HH:mm:ss', 'UTC')
      AS start_period
  FROM readings
  WINDOW TUMBLING (SIZE 60 SECONDS)
  GROUP BY id
  HAVING AVG(reading) > 25
  EMIT CHANGES;